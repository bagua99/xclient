//
//  UIImageView+Yv.h
//  yaya
//
//  Created by wind on 14-8-29.
//  Copyright (c) 2014年 YunVa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (Yv)

//设置头像图标
-(void)setHeadIconImageWithURL:(NSString *)url;

-(void)setHeadIconImageWithURL:(NSString *)url placeholderName:(NSString*)placeholderName;

//设置背景
-(void)yv_setBackgroundImageWithUrl:(NSString *)url;

//设置聊天室头像
-(void)setIMHeadIconWithUrl:(NSString *)url;

//设置聊天室头像
-(void)setLiveShowRoomIMHeadIconWithUrl:(NSString *)url;

/**设置聊天室图像**/
-(void)setLiveShowRoomIconWithUrl:(NSString *)url;

@end
