//
//  YvFontDefine.h
//  yaya
//
//  Created by dada on 15/3/23.
//  Copyright (c) 2015年 com.yunva.yaya. All rights reserved.
//

#ifndef yaya_YvFontDefine_h
#define yaya_YvFontDefine_h

#define kFontListTitle      [UIFont systemFontOfSize:16.0f]//列表标题字体大小
#define kFontListSubTitle      [UIFont systemFontOfSize:13.0f]//列表副标题字体大小
#define kFontListContent      [UIFont systemFontOfSize:11.0f]//列表第二行字体大小

#define kFontNavigationSubTitle      [UIFont systemFontOfSize:13.0f]//导航栏左右两侧跳转字体大小

#endif
