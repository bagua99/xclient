//
//  Utilities.h
//  ChatSDKDemo
//
//  Created by 朱文腾 on 14-8-19.
//  Copyright (c) 2014年 yunva.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Utilities : NSObject

+ (void)showHUD:(NSString *)text andView:(UIView *)view;

+ (void)hideHUDForView:(UIView*)view;

//显示纯文本，并且维持delay秒后自动关闭
+ (void)showTextHUD:(NSString *)text andView:(UIView *)view maintainTime:(NSTimeInterval)delay;

//显示文本维持2秒
+(void)showTextHUDMaintain2Seccond:(NSString*)text;
@end
