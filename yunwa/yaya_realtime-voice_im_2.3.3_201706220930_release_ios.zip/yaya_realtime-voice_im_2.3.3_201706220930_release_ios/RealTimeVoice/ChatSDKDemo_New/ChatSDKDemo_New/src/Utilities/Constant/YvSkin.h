//
//  YvSkin.h
//  yaya
//
//  Created by 朱文腾 on 14-4-30.
//  Copyright (c) 2014年 YunVa. All rights reserved.
//

#import <Foundation/Foundation.h>

#define FontColor [UIColor colorWithRed:204/255.0f green:211/255.0f blue:224/255.0f alpha:1.000]
#define FontColorForSelect [UIColor colorWithRed:78/255.0f green:150/255.0f blue:205/255.0f alpha:1.000]
#define FontColorBlue [UIColor colorWithRed:64/255.0f green:125/255.0f blue:184/255.0f alpha:1.000]
#define FontColorDeep [UIColor colorWithRed:74/255.0f green:83/255.0f blue:103/255.0f alpha:1.000]
#define FontColorKeyWord [UIColor colorWithRed:247/255.0f green:106/255.0f blue:110/255.0f alpha:1.000]

/**********************************************************************/
/*flat new*/
#define FontSizeBig                     17.0
#define FontSizeMid                     14.0
#define FontSizeSmall                   12.0

#define FontColorForWhite [UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1.000]
#define FontColorForGray [UIColor colorWithRed:113/255.0f green:113/255.0f blue:113/255.0f alpha:1.000]
#define FontColorForBlue [UIColor colorWithRed:0/255.0f green:122/255.0f blue:255/255.0f alpha:1.000]
#define FontColorForOrange [UIColor colorWithRed:254/255.0f green:148/255.0f blue:0/255.0f alpha:1.000]
#define FontColorForRed [UIColor colorWithRed:255/255.0f green:105/255.0f blue:105/255.0f alpha:1.000]
#define FontColorForPink [UIColor colorWithRed:255/255.0f green:75/255.0f blue:74/255.0f alpha:1.000]



#define BackgroundColorForUI [UIColor colorWithRed:240/255.0f green:239/255.0f blue:245/255.0f alpha:1.000]//[UIColor colorWithRed:247/255.0f green:247/255.0f blue:247/255.0f alpha:1.000]
#define BackgroundColorForContainer [UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1.000]
#define BorderColorForContainer [UIColor colorWithRed:225/255.0f green:225/255.0f blue:225/255.0f alpha:1.000]
#define MarginForContent    8

#define HeightForTableSection  33
#define HeightForTableRow  70

#define IConSizeForGame   57
#define IConSizeForUser   50
#define IConCornerRadius  25

#define BackgroundColorForCellDelete [UIColor colorWithRed:1.0f green:0.231f blue:0.188 alpha:1.0f]

#define NavigationBarTintColor  [UIColor whiteColor]
#define NavigationBarBackgroundColor [UIColor colorWithRed:4.0/255.0f green:4.0/255.0f blue:4.0/255.0f alpha:1.000]

/*end flat new*/
/**********************************************************************/

#define LineDeepInDeepColor [UIColor colorWithRed:43.0/255.0 green:48.0/255.0 blue:59.0/255.0 alpha:1]
#define LineShallowInDeepColor [UIColor colorWithRed:71.0/255.0 green:77.0/255.0 blue:92.0/255.0 alpha:1]

#define LineDeepInShallowColor [UIColor colorWithRed:70.0/255.0 green:80.0/255.0 blue:103.0/255.0 alpha:1]
#define LineShallowInShallowColor [UIColor colorWithRed:102.0/255.0 green:111.0/255.0 blue:131.0/255.0 alpha:1]

#define BackgroundColorDeep     [UIColor colorWithRed:57 / 255.0 green:65 /255.0 blue:79 / 255.0 alpha:1.0]
#define BackgroundColorMid     [UIColor colorWithRed:67 / 255.0 green:78 /255.0 blue:94 / 255.0 alpha:1.0]
#define BackgroundColorShallow   [UIColor whiteColor]  

//[UIColor colorWithRed:90 / 255.0 green:99 /255.0 blue:120 / 255.0 alpha:1.0]

#define NavigationBackgroundColor  [UIColor colorWithRed:76/255.0f green:161/255.0f blue:254/255.0f alpha:1.000]//#define NavigationBackgroundColor [UIColor colorWithRed:78 / 255.0 green:150 / 255.0 blue:205 / 255.0 alpha:1.0]



#define TopTitleBackgroundColor [UIColor colorWithRed:78/255.0f green:150/255.0f blue:205/255.0f alpha:1.000]

#define ToolBottonBackgroundColor [UIColor colorWithRed:204/255.0f green:211/255.0f blue:224/255.0f alpha:1.000]


#define TopTitleBackgroundColor [UIColor colorWithRed:78/255.0f green:150/255.0f blue:205/255.0f alpha:1.000]

#define SelectCellBackgroundColor [UIColor blackColor]

#define TABLE_ROW_HEIGHT                70.0
#define GameIConCornerRadius            15.0

#define CellBackgroundColor     [UIColor colorWithRed:222/255.0f green:228/255.0f blue:244/255.0f alpha:1.000]


#define SECRETARY_CELL_COLOR            [UIColor redColor]

#define TABLE_COLOR                     [UIColor colorWithRed:94.0 / 255.0 green:99.0 / 255.0 blue:118.0 / 255.0 alpha:1.0]
#define TABLE_SEPERATE_COLOR              [UIColor colorWithRed:85.0 / 255.0 green:91.0 / 255.0 blue:112.0 / 255.0 alpha:1.0]


#define TAB_P_COLOR     [UIColor colorWithRed:213 / 255.0 green:217 / 255.0 blue:223 / 255.0 alpha:1.0]
#define TAB_N_COLOR     [UIColor colorWithRed:61 / 255.0 green:65 /255.0 blue:79 / 255.0 alpha:1.0]

#define BAR_TINT_COLOR  \
[UIColor colorWithRed:105 / 255.0 green:149 / 255.0 blue:203 / 255.0 alpha:1.0]


#define GAMETEAM_MSG_BACKGROUNDCOLOR [[UIColor alloc] initWithRed:67/255.0 green:75/255.0 blue:94/255.0 alpha:1]

#define TABLE_ROW_BACKGROUNDCOLOR [[UIColor alloc] initWithRed:90/255.0 green:99/255.0 blue:120/255.0 alpha:1]

#define CHILDTABLE_ROW_BACKGROUNDCOLOR [[UIColor alloc] initWithRed:57/255.0 green:63/255.0 blue:79/255.0 alpha:1]
