//
//  UIImageView+Yv.m
//  yaya
//
//  Created by wind on 14-8-29.
//  Copyright (c) 2014年 YunVa. All rights reserved.
//

#import "UIImageView+Yv.h"
#import "UIImageView+WebCache.h"

@implementation UIImageView (Yv)

//设置头像图标
-(void)setHeadIconImageWithURL:(NSString *)url
{

    UIImage * placeholderImage = [UIImage imageNamed:@"icon_headIcon_placeholder.png"];
    
    if (!url || url.length == 0) {
        self.image = placeholderImage;
        return;
    }
    NSURL * myUrl = [NSURL URLWithString:url];
    [self setImageWithURL:myUrl placeholderImage:placeholderImage options:SDWebImageRetryFailed|SDWebImageLowPriority];
}


-(void)setHeadIconImageWithURL:(NSString *)url placeholderName:(NSString*)placeholderName
{
    NSURL * myUrl = [NSURL URLWithString:url];
    [self setImageWithURL:myUrl placeholderImage:[UIImage imageNamed:placeholderName] options:SDWebImageRetryFailed|SDWebImageLowPriority];
}


-(void)yv_setBackgroundImageWithUrl:(NSString *)url
{
    NSString * placeholderName = @"yaya3_bk_placeholder.png";
    if (!url || url.length == 0) {
        self.image = [UIImage imageNamed:placeholderName];
        return;
    }
    
    return [self yv_setBackgroundImageWithUrl:url placeholderUrlStr:placeholderName];
}

-(void)yv_setBackgroundImageWithUrl:(NSString *)url placeholderUrlStr:(NSString*)placeholderUrlStr
{
    NSURL * myUrl = [NSURL URLWithString:url];
    [self setImageWithURL:myUrl placeholderImage:[UIImage imageNamed:placeholderUrlStr] options:SDWebImageRetryFailed|SDWebImageLowPriority];
}


-(void)setIMHeadIconWithUrl:(NSString *)url{

    if ((NSNull *)url != [NSNull null]) {
        NSURL *myUrl = [NSURL URLWithString:url];
        [self setImageWithURL:myUrl placeholderImage:[UIImage imageNamed:@"yaya3.2_palytogethterroom_giftdefault"]];
    }

}

-(void)setLiveShowRoomIMHeadIconWithUrl:(NSString *)url{
    
    if ((NSNull *)url != [NSNull null]) {
        NSURL *myUrl = [NSURL URLWithString:url];
        [self setImageWithURL:myUrl placeholderImage:[UIImage imageNamed:@"liveIcon"]];
    }
    
}

-(void)setLiveShowRoomIconWithUrl:(NSString *)url{
    
    if ((NSNull *)url != [NSNull null]) {
        NSURL *myUrl = [NSURL URLWithString:url];
        [self setImageWithURL:myUrl placeholderImage:nil];
    }
    
}

@end
