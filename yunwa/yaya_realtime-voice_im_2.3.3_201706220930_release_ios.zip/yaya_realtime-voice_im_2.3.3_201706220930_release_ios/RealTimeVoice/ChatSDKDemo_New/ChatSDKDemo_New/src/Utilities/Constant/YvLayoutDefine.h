//
//  YvLayoutDefine.h
//  yaya
//
//  Created by dada on 15/3/24.
//  Copyright (c) 2015年 com.yunva.yaya. All rights reserved.
//

#ifndef yaya_YvLayoutDefine_h
#define yaya_YvLayoutDefine_h

#define kCellHeightOneLine      60  //列表内容为一行时高度
#define kCellHeightTwoLine      85  //列表内容为两行时高度
#define kCellHeightMoreLine     90  //列表内容为三行以上时高度




#endif
