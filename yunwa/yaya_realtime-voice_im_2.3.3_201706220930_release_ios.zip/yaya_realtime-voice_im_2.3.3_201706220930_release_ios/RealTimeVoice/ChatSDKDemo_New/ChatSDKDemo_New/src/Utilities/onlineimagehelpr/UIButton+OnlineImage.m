//
//  UIButton+OnlineImage.m
//  yaya
//
//  Created by wind on 5/23/14.
//  Copyright (c) 2014 YunVa. All rights reserved.
//

#import "UIButton+OnlineImage.h"

@implementation UIButton (OnlineImage)


- (void)setOnlineImage:(NSString *)url
{
    [self setOnlineImage:url placeholderImage:nil];
}

- (void)setOnlineImage:(NSString *)url placeholderImage:(UIImage *)image
{
    //[self setImage:image forState:UIControlStateNormal];
    [self setBackgroundImage:image forState:UIControlStateNormal];
    
    AsyncImageDownloader *downloader = [AsyncImageDownloader sharedImageDownloader];
    [downloader startWithUrl:url delegate:self];
}

#pragma mark -
#pragma mark - AsyncImageDownloader Delegate

- (void)imageDownloader:(AsyncImageDownloader *)downloader didFinishWithImage:(UIImage *)image
{
    dispatch_async(dispatch_get_main_queue(), ^{
        //[self setImage:image forState:UIControlStateNormal];
        [self setBackgroundImage:image forState:UIControlStateNormal];
    });
}


@end
