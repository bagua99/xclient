//

//
//  Created by apple on 13-10-26.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "UIImage+Yv.h"
#import "NSString+Yv.h"

@implementation UIImage (Yv)
#pragma mark 加载全屏的图片
// new_feature_1.png
+ (UIImage *)fullscrennImage:(NSString *)imgName
{
    // 1.如果是iPhone5，对文件名特殊处理
    if ([self isIPhone5]) {
        imgName = [imgName fileAppend:@"-568h@2x"];
    }
    
    // 2.加载图片
    return [self imageNamed:imgName];
}

#pragma mark 可以自由拉伸的图片
+ (UIImage *)resizedImage:(NSString *)imgName
{
    return [self resizedImage:imgName xPos:0.5 yPos:0.5];
}

+ (UIImage *)resizedImage:(NSString *)imgName xPos:(CGFloat)xPos yPos:(CGFloat)yPos
{
    UIImage *image = [UIImage imageNamed:imgName];
    return [image stretchableImageWithLeftCapWidth:image.size.width * xPos topCapHeight:image.size.height * yPos];
}


#pragma mark - 颜色生成图片
+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size
{
    CGRect rect = CGRectMake(0, 0, size.width, size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}



+ (BOOL)isGiraffe
{
    static BOOL isGiraffe = NO;
    static BOOL isLoaded = NO;
    
    if (!isLoaded) {
        float height = [UIScreen mainScreen].bounds.size.height;
        if (height == 568.0) {
            isGiraffe = YES;
        }
        isLoaded = YES;
    }
    
    
    return isGiraffe;
}

+ (BOOL)isIPhone5
{
    return [self isGiraffe];
}
@end
