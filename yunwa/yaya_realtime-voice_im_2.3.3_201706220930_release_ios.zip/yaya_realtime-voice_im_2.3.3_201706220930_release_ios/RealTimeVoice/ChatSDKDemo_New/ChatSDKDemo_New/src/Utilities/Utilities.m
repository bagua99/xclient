//
//  Utilities.m
//  ChatSDKDemo
//
//  Created by 朱文腾 on 14-8-19.
//  Copyright (c) 2014年 yunva.com. All rights reserved.
//

#import "Utilities.h"
#import "MBProgressHUD.h"
#import "AppDelegate.h"

@implementation Utilities

+ (void)showHUD:(NSString *)text andView:(UIView *)view
{
    MBProgressHUD *hud = [[MBProgressHUD alloc] initWithView:view];
    [view addSubview:hud];
    hud.labelText = text;
    hud.square = YES;
    [hud show:YES];
}

+ (void)hideHUDForView:(UIView*)view
{
    [MBProgressHUD hideHUDForView:view animated:YES];
}

//显示纯文本，并且维持delay秒后自动关闭
+ (void)showTextHUD:(NSString *)text andView:(UIView *)view maintainTime:(NSTimeInterval)delay
{
    MBProgressHUD *hud = [[MBProgressHUD alloc] initWithView:view];
    [view addSubview:hud];
    hud.labelText = text;
    //    hud.dimBackground = YES;
    hud.mode = MBProgressHUDModeText;
    [hud show:YES];
    [hud hide:YES afterDelay:delay];
}

//显示文本维持2秒
+(void)showTextHUDMaintain2Seccond:(NSString*)text
{
    AppDelegate * appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [self showTextHUD:text andView:appDelegate.window maintainTime:2.0f];
}

@end
