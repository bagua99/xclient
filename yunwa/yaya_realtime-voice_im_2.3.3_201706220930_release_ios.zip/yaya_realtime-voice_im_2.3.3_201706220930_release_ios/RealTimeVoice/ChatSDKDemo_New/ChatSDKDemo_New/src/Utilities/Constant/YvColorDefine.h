//
//  YvColorDefine.h
//  yaya
//
//  Created by dada on 15/3/23.
//  Copyright (c) 2015年 com.yunva.yaya. All rights reserved.
//

#ifndef yaya_YvColorDefine_h
#define yaya_YvColorDefine_h

//color
#define RGB(r, g, b)             [UIColor colorWithRed:((r) / 255.0) green:((g) / 255.0) blue:((b) / 255.0) alpha:1.0]
#define RGBAlpha(r, g, b, a)     [UIColor colorWithRed:((r) / 255.0) green:((g) / 255.0) blue:((b) / 255.0) alpha:(a)]

//RGB转UIColor（不带alpha值）
#define UIColorFromRGB(rgbValue) [UIColor  colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0  green:((float)((rgbValue & 0xFF00) >> 8))/255.0  blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
//RGB转UIColor（带alpha值）
#define UIColorRGBAlpha(rgbValue,a) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:(a)]


#define kColorMainBlue      UIColorFromRGB(0x00c2d4)//主色调颜色，薄荷蓝
#define kColorLightYellow    UIColorFromRGB(0xec510d)//UIColorFromRGB(0xf0ad2b)//辅助颜色，浅黄
#define kColorTextGray      UIColorFromRGB(0x333333)//文字颜色，深灰色
#define kColorTextLightGray UIColorFromRGB(0x888888)//文字颜色，浅灰色
#define kColorBackgroundWhite       UIColorFromRGB(0xffffff)//背景颜色，白色
#define kColorBackgroundGrayWhite   UIColorFromRGB(0xf0f0f0)//背景颜色，灰白色
#define kColorLine                  UIColorFromRGB(0xe1e1e1)//分割线颜色
#define kColorTabbar                UIColorFromRGB(0xf8f9fa)//底部菜单栏颜色
#define kColorBtnBlackGray       UIColorFromRGB(0x75818a) //按钮背景色,深灰色

#endif
