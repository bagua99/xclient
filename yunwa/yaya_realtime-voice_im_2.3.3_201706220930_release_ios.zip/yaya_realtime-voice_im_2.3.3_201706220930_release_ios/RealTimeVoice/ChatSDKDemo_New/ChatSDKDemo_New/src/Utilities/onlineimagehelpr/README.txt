#OnlineImageView
######A category for UIImageView to show images from URLs and make cache.

+ Usage <br/>
<pre>
<code>#import "UIImageView+OnlineImage.h"
<br />/* code omiited */
[self.imageView setOnlineImage:IMAGE_URL];
[self.imageView1 setOnlineImage:IMAGE_URL1 placeholderImage:[UIImage imageNamed:@"question_mark"]];</code>
</pre>