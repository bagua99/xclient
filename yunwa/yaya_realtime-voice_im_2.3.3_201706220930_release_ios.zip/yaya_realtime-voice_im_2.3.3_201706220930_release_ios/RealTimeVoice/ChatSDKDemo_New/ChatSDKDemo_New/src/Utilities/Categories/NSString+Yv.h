//
//  NSString+Yv.h
//  
//
//  Created by apple on 13-10-27.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Yv)

- (NSString *)fileAppend:(NSString *)append;

//去除两边空格
-(NSString *)okw_trimWhitespace;

//是否是手机号码
-(BOOL)isPhoneNumber;

//是否全是数字
-(BOOL)isAllNumber;


//
- (NSString *)replaceCharactersAtIndexes:(NSArray *)indexes withString:(NSString *)aString;


- (NSString*)MD5;
@end
