//
//  UIButton+OnlineImage.h
//  yaya
//
//  Created by wind on 5/23/14.
//  Copyright (c) 2014 YunVa. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AsyncImageDownloader.h"
@interface UIButton (OnlineImage)<AsyncImageDownloaderDelegate>

- (void)setOnlineImage:(NSString *)url;
- (void)setOnlineImage:(NSString *)url placeholderImage:(UIImage *)image;


@end
