//
//  YvRoomViewController.h
//  ChatSDKDemo_New
//
//  Created by huangzj on 15/5/29.
//  Copyright (c) 2015年 com.yunva.yaya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XHVoiceRecordHUD.h"

@interface YvRoomViewController : UIViewController

#pragma mark - config
@property (nonatomic,assign)BOOL isTest;
@property (nonatomic,strong)NSString * Seq;
@property (nonatomic,strong)NSString *AppId;
//ship
@property (nonatomic,assign)BOOL isHaveView;
@property (nonatomic,strong)NSString * videoPostion;
@property (nonatomic,strong)NSString * videoNum;

#pragma mark - UI
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *inputView;
@property (weak, nonatomic) IBOutlet UITextField *textField;//文字输入框
@property (weak, nonatomic) IBOutlet UIButton *recordButton;//语音录制按钮
//@property (weak, nonatomic) IBOutlet UIButton *realTimeVoiceButton;//实时语音按钮
@property (weak, nonatomic) IBOutlet UISwitch *realTimeVoiceSwitch;
@property (weak, nonatomic) IBOutlet UILabel *ExceptionLabel;

@property (nonatomic,strong) XHVoiceRecordHUD * voiceRecordHUD;

#pragma mark - data
@property (nonatomic,strong)NSMutableArray *messageFramesArray;//存储数据 单元是YAChatMessageFrame 类

@end
