//
//  YvConfigViewController.m
//  ChatSDKDemo2
//
//  Created by 李文杰 on 14-11-4.
//  Copyright (c) 2014年 com.yunva.yaya. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import "YvConfigViewController.h"
#import "YvRoomViewController.h"


@interface YvConfigViewController ()
@property (weak, nonatomic) IBOutlet UIButton *enterRoomBtn;

@property (weak, nonatomic) IBOutlet UITextField *app;
@property (weak, nonatomic) IBOutlet UITextField *sign;
@property (weak, nonatomic) IBOutlet UISwitch *swtenviment;
@property (weak, nonatomic) IBOutlet UISwitch *backgroundMusicSwitch;

@property (nonatomic, strong) AVAudioPlayer * avAudioPlayer;
//视频
@property (weak, nonatomic) IBOutlet UISwitch *HasViewOrNot;
@property (weak, nonatomic) IBOutlet UITextField *ViewPostion;
@property (weak, nonatomic) IBOutlet UITextField *ViewNum;

- (IBAction)onBackgroundMusicSwitchAction:(id)sender;

@end

@implementation YvConfigViewController

- (IBAction)enterRoom:(id)sender {
    
    YvRoomViewController * room =[[YvRoomViewController alloc]initWithNibName:@"YvRoomViewController" bundle:nil];

    room.isTest = self.swtenviment.isOn;
    room.AppId = self.app.text;
    room.Seq = self.sign.text;
    //视频参数
    room.isHaveView=self.HasViewOrNot.on;
    room.videoPostion=self.ViewPostion.text;
    room.videoNum=self.ViewNum.text;
//    UIViewController *test = [[UIViewController alloc]init];
//    test.view.backgroundColor=[UIColor blackColor];
    
    [self.navigationController pushViewController:room animated:YES];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
//    [self.swtenviment addTarget:self action:@selector(swtenvimentchange:) forControlEvents:UIControlEventValueChanged];
    self.title = @"配置";
    
    if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//结束编辑收起键盘
- (IBAction)endEditTap:(id)sender {
    [self.view endEditing:YES];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.app resignFirstResponder];
    [self.sign resignFirstResponder];
}

-(void)playMP3
{
    NSError *error;
    BOOL pp =[[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategorySoloAmbient withOptions:0 error:nil];
    [[AVAudioSession sharedInstance] setActive:YES error:nil];
  
    NSString *string = [[NSBundle mainBundle] pathForResource:@"background-music-aac" ofType:@"wav"];//@"background-music-aac" ofType:@"wav"];
    //把音频文件转换成url格式
    NSURL *url = [NSURL fileURLWithPath:string];
    //初始化音频类 并且添加播放文件
    self.avAudioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
    
    BOOL exist = [[NSFileManager defaultManager] fileExistsAtPath:string];
    
    NSLog(@" url = %@, exist = %d, self.avAudioPlayer = %@", url, exist, self.avAudioPlayer);
    //设置代理
    //avAudioPlayer.delegate = self;
    
    //设置初始音量大小
     _avAudioPlayer.volume = 0.1;
    
    //设置音乐播放次数  -1为一直循环
     self.avAudioPlayer.numberOfLoops = -1;
    
    
    //预播放
    [self.avAudioPlayer prepareToPlay];
    
    [self.avAudioPlayer play];
    
//    [[AVAudioSession sharedInstance] setActive:NO error:nil];
//    [[AVAudioSession  sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionDefaultToSpeaker  error:nil];
//    [[AVAudioSession sharedInstance] setActive:YES error:&error];
    
    
}


-(void)dealloc
{
    NSLog(@" %s dealloc", __FUNCTION__);
}
- (IBAction)onBackgroundMusicSwitchAction:(id)sender {
    
    if (self.backgroundMusicSwitch.on) {
        [self playMP3];
    }
    else
    {
        [self.avAudioPlayer  stop];
    }
}
@end
