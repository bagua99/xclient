//
//  YvConfigViewController.h
//  ChatSDKDemo2
//
//  Created by 李文杰 on 14-11-4.
//  Copyright (c) 2014年 com.yunva.yaya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YvConfigViewController : UIViewController



@end
