//
//  YAChatMessage.m
//  ChattingRoom
//
//  Created by wind on 5/4/14.
//  Copyright (c) 2014 wind. All rights reserved.
//

#import "YAChatMessage.h"


@interface YAChatMessage()
{
    //NSInteger _messageIndex;
}

@end

@implementation YAChatMessage


//- (id)initWithMessage:(NSString *)_icon  nickName:(NSString *)_nickName time:(NSDate *)_time content:(NSString *)_content style:(YAMessageStyle)_messageStyle targetId:(UInt32)targetId withIndex:(NSUInteger)index;
- (id)initWithMessage:(NSString *)icon nickName:(NSString *)nickName time:(NSDate *)time content:(NSString *)content style:(YAMessageStyle)messageStyle withUniqueId:(NSInteger)uniqueId
{
    if (self = [super init])
    {
        _iconUrl = icon;
        _time = time;
        _content = content;
        _nickName = nickName;
        _messageStyle = messageStyle;
        _mode = YAContentModeCommonText;
        //self.targetId = targetId;
        //_messageIndex = index;
        _uniqueId = uniqueId;
        
    }
    return self;
}


@end
