//
//  ParamViewController.h
//  ChatSDKDemo_New
//
//  Created by huangzj on 15/6/1.
//  Copyright (c) 2015年 com.yunva.yaya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YvChatManage.h"
#import "YvAudioTools.h"


@protocol ParamViewDelegate <NSObject>

-(void)ParamViewMicModeChange:(int)modetype;//麦模式值被修改回调

-(void)ParamViewRecognizeEnableChange:(BOOL)recognizeEnable;//是否启用语音识别 值被修改回调


-(void)ParamViewRecognizeLanguageChange:(E_TVoiceRecognitionLanguage)recognizeLanguage;//值被修改回调

-(void)ParamViewOutputTextLanguageTypeChange:(E_OutputLanguageType) outputTextLanguageType;//值被修改回调


@end

@interface ParamViewController : UIViewController

#pragma mark - UI

#pragma mark 语音消息控制

@property (weak, nonatomic) IBOutlet UISwitch *recognizeEnable_Switch;

@property (weak, nonatomic) IBOutlet UISwitch *voiceRecordMeteringEnable_Switch;

@property (weak, nonatomic) IBOutlet UISegmentedControl *recognizeLanguage_seg;

@property (weak, nonatomic) IBOutlet UISegmentedControl *outputTextLanguageType_seg;


#pragma mark 实时语音控制

@property (weak, nonatomic) IBOutlet UISwitch *realTimeVoice_Mute_Switch;

@property (weak, nonatomic) IBOutlet UISwitch *realTimeVoice_MeteringEnable_Switch;


@property (weak, nonatomic) IBOutlet UISegmentedControl *realTimeVoice_MicMode_seg;

#pragma mark 其他控制
@property (weak, nonatomic) IBOutlet UISegmentedControl *logLevel_Seg;


#pragma mark 
@property (nonatomic,weak) id<ParamViewDelegate> delegate;
@property (nonatomic,weak) YvAudioTools * audioTools;

@property (nonatomic,assign) int realTimeVoice_MicMode;
@property (nonatomic, assign) BOOL recognizeEnable;//是否启用语音识别功能

@property (nonatomic, assign) E_TVoiceRecognitionLanguage recognizeLanguage;//语音识别 语言类型
@property (nonatomic, assign) E_OutputLanguageType outputTextLanguageType;//语音识别 输出文字类型

@end
