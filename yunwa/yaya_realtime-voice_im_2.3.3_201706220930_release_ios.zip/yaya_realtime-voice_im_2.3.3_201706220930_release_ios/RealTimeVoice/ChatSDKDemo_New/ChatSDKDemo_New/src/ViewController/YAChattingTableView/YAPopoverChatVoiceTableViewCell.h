//
//  YAPopoverChatVoiceTableViewCell.h
//  ChattingRoom
//
//  Created by 朱文腾 on 5/27/14.
//  Copyright (c) 2014 wind. All rights reserved.
//

#import "YAPopoverChatTableViewCell.h"
#import "YARichText.h"
#import "UCZProgressView.h"

@interface YAPopoverChatVoiceTableViewCell : YAPopoverChatTableViewCell
{
    YARichText *richText;
}

@property (nonatomic,strong) UIImageView  *voiceImageView;
@property (nonatomic,strong) UILabel *voiceTimeLabel;
@property (nonatomic,strong) UCZProgressView * voiceDownloadProgressView;


@property (nonatomic,assign) int voicePlaySequenceId;

-(void)voicePlayStart;
-(void)voicePlayStop;


-(void)showVoiceDownloadProgress;
-(void)setVoiceDownloadProgress:(float)progress;
-(void)hideVoiceDownloadProgress;

@end
