//
//  YvRoomViewController.m
//  ChatSDKDemo_New
//
//  Created by huangzj on 15/5/29.
//  Copyright (c) 2015年 com.yunva.yaya. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Utilities.h"
#import "YvRoomViewController.h"
#import "YAPopoverChatTableViewCell.h"
#import "YAPopoverChatTextTableViewCell.h"
#import "YAPopoverChatVoiceTableViewCell.h"
#import "ParamViewController.h"
#import "YvRealVideoController.h"

#import <AVFoundation/AVFoundation.h>

//sdk引用头文件
#import "YvChatManage.h"
//#import "YvChatManage+Video.h"
#import "YvAudioTools.h"

//#import "YvDnsManage.h"




#define showHud 1
#define kResultSuccess  (0)

static inline UIViewAnimationOptions RDRAnimationOptionsForCurve(UIViewAnimationCurve curve) {
    return (curve << 16 | UIViewAnimationOptionBeginFromCurrentState);
}

static int s_viewY = 0;
@interface YvRoomViewController ()<UITableViewDataSource,UITableViewDelegate,ParamViewDelegate, YvAudioToolsDelegate, YvChatManageDelegate>
{
    
    
    int _playingAudioSequenceId;//正在播放的播放序号
    E_MicModeType _realTimeVoice_MicModeType;//实时语音麦模式
    
    BOOL _isHistoryMessageLoaded;//历史消息是否已经加载过了
    
    //czw
    NSTimer* updateTimer;
    //czw 2016 - 3 -6
    BOOL _isAutoConnectVideo ;//(default Yes) sdk自动管理视频连接等操作
    
    NSInteger count;
  
}


@property (nonatomic, assign) NSUInteger yunvaId;
@property (nonatomic, assign) NSUInteger messageUnique;

@property (nonatomic, strong) YvAudioTools * audioTools;

@property (nonatomic, assign) E_TVoiceRecognitionLanguage recognizeLanguage;
@property (nonatomic, assign) E_OutputLanguageType outputTextLanguageType;

@property (weak, nonatomic) IBOutlet UILabel *timeDelay;

@property (nonatomic, assign) BOOL recognizeEnable;//是否启用语音识别功能

//czw
@property (nonatomic, strong) AVAudioPlayer * avAudioPlayer;

//czw

- (IBAction)sendTextAction:(id)sender;

@end

@implementation YvRoomViewController


-(void)dealloc
{
    NSLog(@" YvRoomViewController === dealloc");
    //czw 2016 - 3 -6
    [updateTimer invalidate];
    updateTimer = nil;
    
    //czw 2016 - 3 -
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    
    
    //_isAutoConnectVideo：NO 标示：手动管理视频   Yes：表示，Sdk管理视频。可以跟踪_isAutoConnectVideo 看看
    _isAutoConnectVideo = YES;
    

    

    
    
    [self configEnv];
    [self configUI];
    
    [self __chatSDK_Init];//SDK初始化
    
    [Utilities showHUD:@"进入房间中..." andView:self.view];
    
    BOOL isT = NO;

    NSDictionary * dic = @{@"aa":@(isT)};
    
    
    NSString * json = [self __getJsonStringWithDictionary:dic];
    
    MicModeChangeNotify * n = [[MicModeChangeNotify alloc] init];
    
    n.modeType = 1;
    n.isLeader = YES;
    
    YvDebugLog(@" json = %@,  notify = %@", json, [n jsonString]);
    
    
    //czw  模拟，录制的时候停止背景音乐，停止录制的时候恢复背景音乐
//    [self playMP3];
    
    //czw
}


- (NSString *)__getJsonStringWithDictionary:(NSDictionary*)dic
{
    NSData * data = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    NSString * jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    return jsonString;
}

//配置环境
- (void)configEnv {
    
    // data:
    self.messageFramesArray = [[NSMutableArray alloc]init];
    self.messageUnique = 1;
    
    self.recognizeEnable = YES;
    
    _playingAudioSequenceId = -1;
    _isHistoryMessageLoaded = NO;

}
//配置UI
- (void)configUI
{
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        // iOS7——UIControlEventTouchDown延迟响应问题
        self.navigationController.interactivePopGestureRecognizer.delaysTouchesBegan=NO;
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
    
    
    //_isPullDownRefresh = YES;
    [self.view setBackgroundColor:[UIColor whiteColor]];
    self.navigationItem.title = @"房间";
    
    self.tableView.backgroundColor = [UIColor whiteColor];//BackgroundColorForUI;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    //键盘return类型--可以是发送
    self.textField.returnKeyType = UIReturnKeySend;
    self.textField.delegate = self;
    
    
    UITapGestureRecognizer * gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeybored)];
    [self.inputView addGestureRecognizer:gesture];
    
    
    [self.recordButton addTarget:self action:@selector(__YvAudioTools_StartRecord) forControlEvents:UIControlEventTouchDown];
    [self.recordButton addTarget:self action:@selector(__YvAudioTools_StopRecord) forControlEvents:UIControlEventTouchUpInside];
    [self.recordButton addTarget:self action:@selector(__YvAudioTools_StopRecord) forControlEvents:UIControlEventTouchUpOutside];
    /*
    [self.realTimeVoiceButton addTarget:self action:@selector(realTimeVoice_StartAction) forControlEvents:UIControlEventTouchDown];
    [self.realTimeVoiceButton addTarget:self action:@selector(realTimeVoice_StopAction) forControlEvents:UIControlEventTouchUpInside];
    [self.realTimeVoiceButton addTarget:self action:@selector(realTimeVoice_StopAction) forControlEvents:UIControlEventTouchUpOutside];
     */
    
    [self.realTimeVoiceSwitch addTarget:self action:@selector(realTimeVoice_SwitchValueChanged) forControlEvents:UIControlEventValueChanged];
    
    
    if ([[UIDevice currentDevice].systemVersion floatValue] > 7.0) {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardshow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardhide:) name:UIKeyboardWillHideNotification object:nil];
    
    
    //
    UIBarButtonItem * leftBarBtn = [[UIBarButtonItem alloc] initWithTitle:@"退出" style:UIBarButtonItemStylePlain target:self action:@selector(leftBarButtonAction)];
    self.navigationItem.leftBarButtonItem = leftBarBtn;
    

    //
    UIBarButtonItem * rightBarBtn = [[UIBarButtonItem alloc] initWithTitle:@"参数" style:UIBarButtonItemStylePlain target:self action:@selector(rightBarButtonAction)];
    
//    UIBarButtonItem * rightBarBtnForvideo = [[UIBarButtonItem alloc] initWithTitle:@"视频" style:UIBarButtonItemStylePlain target:self action:@selector(rightBarButtonActionForVideo)];
    
 //   self.navigationItem.rightBarButtonItems = @[rightBarBtnForvideo,rightBarBtn];
    self.navigationItem.rightBarButtonItems = @[rightBarBtn];
}

#pragma mark - SDK 初始化
-(void)__chatSDK_Init
{
//    self.AppId = @"100041";
    /********** YvChatManage 初始化  *********/
    [self __ChatManage_initWithAppId:self.AppId isTest:self.isTest];//单例初始化
    [[YvChatManage sharedInstance] setLogLevel:2];

    /********** YvAudioTools 初始化  *********/
    [self __YvAudioTools_Init];
    [self __ChatManage_LoginWithSeq:self.Seq];//登录操作
 //       [self __ChatManage_LoginBindingWithTT:nil seq:self.Seq];
    
}

#pragma mark - BarButton设置
-(void)leftBarButtonAction
{
    [self.voiceRecordHUD stopRecordCompled:^(BOOL fnished) {
    }];
    
    [self __YvAudioTools_stopPlayAudio];//如果正在播放则停止播放
    [self __YvAudioTools_StopRecord];//如果正在录制则停止录制

    [self __ChatManage_Logout];//发注销命令给服务器。
    
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)rightBarButtonAction
{
    

    
    
    [self.voiceRecordHUD stopRecordCompled:^(BOOL fnished) {
    }];
    
    ParamViewController * paramViewController = [[ParamViewController alloc] initWithNibName:@"ParamViewController" bundle:nil];
    
    paramViewController.delegate = self;
    paramViewController.audioTools = self.audioTools;
    paramViewController.realTimeVoice_MicMode = _realTimeVoice_MicModeType;
    paramViewController.recognizeEnable = self.recognizeEnable;
    paramViewController.recognizeLanguage = self.recognizeLanguage;
    paramViewController.outputTextLanguageType = self.outputTextLanguageType;
    
    [self.navigationController pushViewController:paramViewController animated:YES];
}

-(void)rightBarButtonActionForVideo
{
//    if ([YvChatManage sharedInstance].isFull)
    {
        [Utilities showTextHUD:@"视频已经满了" andView:self.view maintainTime:1];
        return;
    }
    if ([self.videoPostion intValue] >4 || [self.videoPostion intValue] <0) {
        [Utilities showTextHUD:@"你输入的视频位置错误" andView:self.view maintainTime:2];
        return;
    }
    if ([self.videoNum integerValue]>5 || [self.videoNum integerValue]<2) {
        [Utilities showTextHUD:@"你输入的视频数量错误" andView:self.view maintainTime:2];
        return;
    }
    
    YvRealVideoController *VideoController=[[YvRealVideoController alloc]init];
    VideoController.position = [self.videoPostion intValue];
    VideoController.videoCount = [self.videoNum integerValue];
    [self.navigationController pushViewController:VideoController animated:YES];
}
#pragma mark - //----------------------------参数设置页面代理回调-------------------------//
#pragma mark - 参数设置页面 设置的参数改变值回调

//参数 设置界面 设置了麦序的回调
-(void)ParamViewMicModeChange:(int)modetype
{
    YvDebugLog(@"set  mic  modetype = %d",modetype);
    _realTimeVoice_MicModeType = modetype;
    [self __ChatManage_MicModeSettingWithmodeType:_realTimeVoice_MicModeType];
}

//参数 设置页面 设置了是否启用语音识别功能回调
-(void)ParamViewRecognizeEnableChange:(BOOL)recognizeEnable
{
    YvDebugLog(@"set recognizeEnable = %d",recognizeEnable);
    self.recognizeEnable = recognizeEnable;
}

-(void)ParamViewRecognizeLanguageChange:(E_TVoiceRecognitionLanguage)recognizeLanguage//值被修改回调
{
    YvDebugLog(@"set recognizeLanguage = %d",recognizeLanguage);
    self.recognizeLanguage = recognizeLanguage;
}

-(void)ParamViewOutputTextLanguageTypeChange:(E_OutputLanguageType) outputTextLanguageType//值被修改回调
{
    YvDebugLog(@"set outputTextLanguageType = %d",outputTextLanguageType);
    self.outputTextLanguageType = outputTextLanguageType;
}

#pragma mark - 键盘显示隐藏
#pragma mark UIEvent

-(void)keyboardshow:(NSNotification *)notification
{
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        s_viewY = self.view.frame.origin.y;
    });
    
    CGSize keyboardSize_end = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    CGFloat keyboardheight = keyboardSize_end.height;
    
    
    NSDictionary *userInfo = notification.userInfo;
    CGRect endFrame = [userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGRect beginFrame = [userInfo[UIKeyboardFrameBeginUserInfoKey] CGRectValue];
    CGFloat duration = [userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    UIViewAnimationCurve curve = [userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue];
    
    
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:RDRAnimationOptionsForCurve(curve)
                     animations:^{
                         
                         /****/
                         CGRect selfframe = self.view.frame;
                         selfframe.origin.y = s_viewY - keyboardheight;//(selfframe.origin.y - keyboardheight);
                         self.view.frame = selfframe;
                         /****/

                     }
                     completion:nil];
    

    
}

-(void)keyboardhide:(NSNotification *)notification
{
    NSDictionary *userInfo = notification.userInfo;
    CGRect endFrame = [userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGRect beginFrame = [userInfo[UIKeyboardFrameBeginUserInfoKey] CGRectValue];
    CGFloat duration = [userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    UIViewAnimationCurve curve = [userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue];
    
    
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:RDRAnimationOptionsForCurve(curve)
                     animations:^{
                         
                         CGRect selfframe = self.view.frame;
                         selfframe.origin.y = s_viewY;
                         self.view.frame = selfframe;

                     }
                     completion:nil];
    

    
}


-(void)hideKeybored
{
    [self.textField resignFirstResponder];
}


#pragma mark - 内部函数
-(void)showAlertViewTitle:(NSString *)title message:(NSString*) message
{
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil, nil];
    
    [alert show];
}


#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    YAChatMessageFrame *frame = [self.messageFramesArray objectAtIndex:[indexPath row]];

    return [frame getFrameHeight] + 10;
}
#pragma mark UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.messageFramesArray count];
}

#define CELL_IDENTIFIER_COMMTEXT    @"PopOverCellCommonText"
#define CELL_IDENTIFIER_VOICE       @"PopOverCellVoice"


- (YAPopoverChatTableViewCell *)dequeueReusableCellWithIdentifier:(NSString *)identifier {
    
    YAPopoverChatTableViewCell *cell = nil;
    if ([identifier isEqualToString:CELL_IDENTIFIER_COMMTEXT]) {
        cell = [[YAPopoverChatTextTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_COMMTEXT];
    }
    else if([identifier isEqualToString:CELL_IDENTIFIER_VOICE]){
        cell = [[YAPopoverChatVoiceTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_VOICE];
    }

    return cell;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"PopOverCell";
    YAChatMessageFrame *frame = [self.messageFramesArray objectAtIndex:[indexPath row]];

        if (frame.chatMessage.mode == YAContentModeCommonText)
        {
            CellIdentifier = CELL_IDENTIFIER_COMMTEXT;
        }
        else if(frame.chatMessage.mode == YAContentModeVoice)
        {
            CellIdentifier = CELL_IDENTIFIER_VOICE;
        }

        
        YAPopoverChatTableViewCell *cell = (YAPopoverChatTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [self dequeueReusableCellWithIdentifier:CellIdentifier];
            //cell.backgroundColor = BackgroundColorShallow;
            [cell setDelegate:self];
        }
        
        //cell.messageFrame = frame;
    
        [cell setMessageFrame:frame];
        return cell;
    
}

#pragma mark - YAPopoverChatTableViewCellDelegate
#pragma mark  按到播放语音
- (void)contentDidSelected:(id)obj
{
    if ([obj isKindOfClass:[YAPopoverChatVoiceTableViewCell class]]) { //界面语音条被点击
        
        YAPopoverChatVoiceTableViewCell * voiceCell = (YAPopoverChatVoiceTableViewCell *)obj;
        
        BOOL isAudioPlaying = [self __YvAudioTools_isPlaying];
        
        if (isAudioPlaying
            && ([voiceCell voicePlaySequenceId] == _playingAudioSequenceId)) {//再次点击了当前正在播放
            
            /**停止语音播放**/
            [self __YvAudioTools_stopPlayAudio];
        }
        else
        {
            /**开始语音播放**/
            
            YAChatMessageVoice * voiceMessage = (YAChatMessageVoice *)voiceCell.messageFrame.chatMessage;
            NSLog(@"contentDidSelected| voiceUrl = %@, voiceFilePath = %@",voiceMessage.voiceUrl,voiceMessage.voiceFilePath);
            int playSequenceId = -1;
            if (voiceMessage.voiceUrl && voiceMessage.voiceUrl.length > 0) {
                //播放url
                
                
                BOOL isShowVoiceDowdloadProgress = YES;
                
                if (isShowVoiceDowdloadProgress)
                {
                    //播放需显示语音下载进度
                    playSequenceId =  [self playOnlineAudioWithDownloadProgress:voiceMessage.voiceUrl voiceCell:voiceCell];
                }
                else
                {
                    //播放不需显示下载进度
                    playSequenceId = [self playOnlineAudio:voiceMessage.voiceUrl];
                }

            }
            else
            {
                //播放语音文件
                playSequenceId =[self __YvAudioTools_playAudio:voiceMessage.voiceFilePath];
            }
            
            
            
            [self playStartedHandle:playSequenceId voiceCell:voiceCell];
        }
        


    }
}

//在线播放语音
-(int)playOnlineAudio:(NSString *)voiceUrl
{
   return  [self __YvAudioTools_playOnlineAudio:voiceUrl];
}

//在线播放语音 ---增加语音下载进度显示
-(int)playOnlineAudioWithDownloadProgress:(NSString *)voiceUrl voiceCell:(YAPopoverChatVoiceTableViewCell *) voiceCell
{
    [voiceCell showVoiceDownloadProgress];//显示下载进度控件
    
    __weak __typeof(&*self)weakSelf = self;
   int playSequenceId = [self __YvAudioTools_playOnlineAudio:voiceUrl downloadProgress:^(int totalSize, int progressSize, NSString *fileurl, int playSequenceId) {
       
       //进度回调函数处理
       __strong __typeof(&*weakSelf)strongSelf = weakSelf;
       if (!strongSelf) {
           return;
       }
       
        YvDebugLog(@" downloadProgress isMainThread = %d, totalSize = %d, progressSize = %d",[NSThread isMainThread], totalSize, progressSize);
       YAPopoverChatVoiceTableViewCell * voiceCell = [strongSelf getVoiceCellWithPlaySequenceId:playSequenceId];
       
       if (voiceCell) {
            [voiceCell setVoiceDownloadProgress:(float)progressSize/totalSize];//刷进度
       }
       
        
    } downloadFinished:^(int result, NSString *errMsg, NSString *fileurl, int playSequenceId) {
        
        //下载完成回调函数处理
        __strong __typeof(&*weakSelf)strongSelf = weakSelf;
        if (!strongSelf) {
            return;
        }
        
        YvDebugLog(@" downloadFinished isMainThread = %d",[NSThread isMainThread]);
        YAPopoverChatVoiceTableViewCell * voiceCell = [strongSelf getVoiceCellWithPlaySequenceId:playSequenceId];
        if (voiceCell) {
            [voiceCell hideVoiceDownloadProgress];//关闭下载进度控件
        }
        
    }];
    
    return playSequenceId;
}


#pragma mark UIScrollViewDelegate
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}

#pragma mark - UI插入新消息
- (void)addMessage:(YAChatMessage *)message {
    NSMutableArray * insertIdxPaths = [[NSMutableArray alloc] init];

    //内容
    YAChatMessageFrame *myMessageFrame = [[YAChatMessageFrame alloc]initWithMesssage:message delegate:self];
 
    [self.messageFramesArray addObject:myMessageFrame];
    
    NSIndexPath *insertIdxPath = [NSIndexPath indexPathForRow:self.messageFramesArray.count - 1 inSection:0];
    [insertIdxPaths addObject:insertIdxPath];
    
    [self.tableView beginUpdates];
    [self.tableView insertRowsAtIndexPaths:insertIdxPaths withRowAnimation:UITableViewRowAnimationFade];
    [self.tableView endUpdates];
    
    [self.tableView scrollToRowAtIndexPath:insertIdxPath atScrollPosition:UITableViewScrollPositionBottom animated:TRUE];

}

#pragma mark UI插入接收的消息

//收到的文本消息添加到UI
-(void)UI_addRecivedTextMessage:(TextMessageNotify *)textMessageNotify
{
    //收到 文本消息，插入显示
    NSString * nickName = [NSString stringWithFormat:@"yunvaId:%d", textMessageNotify.yunvaId];
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:textMessageNotify.time];
    
    NSUInteger uniqueId = [self createUniqueId];
    YAChatMessage *textMsg = [[YAChatMessage alloc] initWithMessage:nil nickName:nickName time:date content:textMessageNotify.text style:YAMessageStyleLeft withUniqueId:uniqueId];
    
    [self addMessage:textMsg];
}

//收到的语音消息添加到UI
-(void)UI_addRecivedVoiceMessage:(VoiceMessageNotify *)voiceMessageNotify
{
    NSString * nickName = [NSString stringWithFormat:@"yunvaId:%d", voiceMessageNotify.yunvaId];
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:voiceMessageNotify.time];
    NSString * voiceDurationString = [NSString stringWithFormat:@"%.1f\'\'", (float)voiceMessageNotify.voiceTime/1000];
    
    NSUInteger uniqueId = [self createUniqueId];
    YAChatMessageVoice *voiceMsg = [[YAChatMessageVoice alloc] initWithMessage:nil nickName:nickName time:date voiceUrl:voiceMessageNotify.voiceUrl voiceFilePath:nil voiceTime:voiceDurationString style:YAMessageStyleLeft withUniqueId:uniqueId]; //
    [self addMessage:voiceMsg];

}

//收到富消息添加到UI
-(void)UI_adddRecivedRichMessage:(TextMessageNotify *)textMessageNotify voiceMessageNotify:(VoiceMessageNotify *)voiceMessageNotify
{
    NSString * nickName = [NSString stringWithFormat:@"yunvaId:%d", voiceMessageNotify.yunvaId];
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:voiceMessageNotify.time];
    NSString * voiceDurationString = [NSString stringWithFormat:@"%.1f\'\'", (float)voiceMessageNotify.voiceTime/1000];
    
    NSUInteger uniqueId = [self createUniqueId];
    YAChatMessageVoice *voiceMsg = [[YAChatMessageVoice alloc] initWithMessage:nil nickName:nickName time:date voiceUrl:voiceMessageNotify.voiceUrl voiceFilePath:nil voiceTime:voiceDurationString style:YAMessageStyleLeft withUniqueId:uniqueId]; //
    
    voiceMsg.content = textMessageNotify.text;//文本消息
    [self addMessage:voiceMsg];
}

#pragma mark UI插入发送的消息

//UI插入发送的文本消息
-(YAChatMessage *)UI_addSendTextMessage:(NSString *)textMessage sendTime:(NSDate *)sendTime uniqueId:(NSUInteger)uniqueId
{

    NSString * nickName = [NSString stringWithFormat:@"user:%lu",self.yunvaId];
    YAChatMessage *myMessage = [[YAChatMessage alloc]initWithMessage:nil
                                                            nickName:nickName time:sendTime content:textMessage style:YAMessageStyleRight withUniqueId:uniqueId];
    [self addMessage:myMessage];
    
    return myMessage;
}

//UI插入发送的语音消息
-(YAChatMessageVoice *)UI_addSendVoiceMessageWithVoiceUrl:(NSString *)voiceUrl voiceFilePath:(NSString *)voiceFilePath voiceDuration:(int)voiceDuration text:(NSString *)text sendTime:(NSDate *)sendTime uniqueId:(NSUInteger)uniqueId
{
    NSString * nickName = [NSString stringWithFormat:@"yunvaId:%ld", self.yunvaId];
    //NSDate *date = [NSDate date];
    NSString * voiceDurationStr = [NSString stringWithFormat:@"%.1f\'\'", (float)voiceDuration/1000];//voiceDuration 单位为毫秒
    
    YAChatMessageVoice *voiceMsg = [[YAChatMessageVoice alloc] initWithMessage:nil nickName:nickName time:sendTime voiceUrl:voiceUrl voiceFilePath:voiceFilePath voiceTime:voiceDurationStr style:YAMessageStyleRight withUniqueId:uniqueId];
    
    
    voiceMsg.content = text;
    
    [self addMessage:voiceMsg];
    
    return voiceMsg;
}


#pragma mark - 内部函数

//创一个新的uniqueId
-(NSUInteger)createUniqueId
{
    NSUInteger uniqueId;
    @synchronized(self)
    {
        uniqueId = self.messageUnique++;
    }
    return uniqueId;
}




//根据uniqueId 查询 对应的 YAChatMessage
-(YAChatMessageFrame *)getChatMessageFrameFromUniqueId:(NSUInteger)uniqueId
{
    for (YAChatMessageFrame *messageFrame in self.messageFramesArray) {
        
        if (uniqueId == messageFrame.chatMessage.uniqueId) {
            return messageFrame;
        }
    }
    
    return nil;
}

//根据uniqueId 查询uniqueId 对应的 messageFrame 在  数组 self.messageFrames 的位置index
-(NSUInteger)getIndexChatMessageFrameFromUniqueId:(NSUInteger)uniqueId
{
    
    for (YAChatMessageFrame *messageFrame in self.messageFramesArray) {
        
        if (uniqueId == messageFrame.chatMessage.uniqueId) {
            return [self.messageFramesArray indexOfObject:messageFrame];
        }
    }
    
    return 0;
}

//关闭发送等待Activity图标
-(void)closeActivityIndicatorWithUniqueId:(NSUInteger)uniqueId
{
    //1.设置为状态为不显示
    YAChatMessageFrame *messageFrame = [self getChatMessageFrameFromUniqueId:uniqueId];
    messageFrame.showActivityIndicator = NO;
    
    //2.设置cell 关闭显示
    NSInteger index = [self getIndexChatMessageFrameFromUniqueId:uniqueId];
    if(index >= 0)
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        YAPopoverChatTableViewCell *cell = (YAPopoverChatTableViewCell *)[self.tableView cellForRowAtIndexPath:indexPath];
        if (cell) {
            [cell showActivityIndicator:NO];
        }
        
    }
    
    YvDebugLog(@"uniqueId = %d, index = %d", uniqueId, index);
}

//根据uniqueId  在对应的cell  显示对应的错误信息
-(void)showSendErrorWithUniqueId:(NSUInteger)uniqueId
{
    //1.
    YAChatMessageFrame *messageFrame = [self getChatMessageFrameFromUniqueId:uniqueId];
    messageFrame.isShowSendError = YES;
    
    //2.
    NSInteger index = [self getIndexChatMessageFrameFromUniqueId:uniqueId];
    if(index >= 0)
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        YAPopoverChatTableViewCell *cell = (YAPopoverChatTableViewCell *)[self.tableView cellForRowAtIndexPath:indexPath];
        if (cell) {//当index是当前tableview 可见的情况下才能获取到cell
            
            [cell showSendErrorPrompt:YES];
        }
        
    }
}

//更新界面cell中的语音识别文本
-(void)updateVoiceRecognizeText:(NSString *)text UniqueId:(NSUInteger)uniqueId
{
    //1.设置语音识别的文字
    YAChatMessageFrame *messageFrame = [self getChatMessageFrameFromUniqueId:uniqueId];
    messageFrame.chatMessage.content = text;
    [messageFrame updateRect];
    
    //2.重绘cell
    //2.设置cell 关闭显示
    NSInteger index = [self getIndexChatMessageFrameFromUniqueId:uniqueId];
  
    
    if(index >= 0)
    {
          NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
          [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    
}

//启动播放后续操作
-(void)playStartedHandle:(int)playSequenceId voiceCell:(YAPopoverChatVoiceTableViewCell *)voiceCell
{
    if (-1 != _playingAudioSequenceId
        && _playingAudioSequenceId != playSequenceId) {
        
        //有正在播放的，先停掉上一个播放的
        [self playFinishedHandle:_playingAudioSequenceId];
    }
    
    [voiceCell setVoicePlaySequenceId:playSequenceId];//内部已经把 messageFrame 的 voicePlaySequenceId 设置了
    
    [voiceCell voicePlayStart];//启动播放语音动画
    
    _playingAudioSequenceId = playSequenceId;
}

 //播放结束后续操作
-(void)playFinishedHandle:(int)playSequenceId
{
    //根据播放顺序id playSequenceId 查询对应的 messageFrame
    NSInteger index  = -1;
    YAChatMessageFrame * stopedMessageFrame = nil;
    for (YAChatMessageFrame *messageFrame in self.messageFramesArray) {
        
        if (playSequenceId == messageFrame.voicePlaySequenceId) {
            
            stopedMessageFrame = messageFrame;
            index = [self.messageFramesArray indexOfObject:messageFrame];
            break;
        }
    }
    
    //设置标志位
    stopedMessageFrame.isPlaying = NO;
    
    //
    if(index >= 0)
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        YAPopoverChatVoiceTableViewCell *voiceCell = (YAPopoverChatVoiceTableViewCell *)[self.tableView cellForRowAtIndexPath:indexPath];
        
        if (voiceCell && [voiceCell respondsToSelector:@selector(voicePlayStop)]) {
            [voiceCell voicePlayStop];//关闭播放语音动画
        }
        else
        {
            NSLog(@"playStopedHandle| can not find cell");
        }
        
    }
    
    _playingAudioSequenceId = -1;
}


-(YAPopoverChatVoiceTableViewCell *)getVoiceCellWithPlaySequenceId:(int)playSequenceId
{
    YAPopoverChatVoiceTableViewCell *voiceCell = nil;
    NSInteger index  = -1;
    YAChatMessageFrame * selectedMessageFrame = nil;
    for (YAChatMessageFrame *messageFrame in self.messageFramesArray) {
        
        if (playSequenceId == messageFrame.voicePlaySequenceId) {
            
            selectedMessageFrame = messageFrame;
            index = [self.messageFramesArray indexOfObject:messageFrame];
            break;
        }
    }
    
    
    //
    if(index >= 0)
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        voiceCell = (YAPopoverChatVoiceTableViewCell *)[self.tableView cellForRowAtIndexPath:indexPath];
        
    }
    
    return voiceCell;

}


//删除文件
-(BOOL)deleteFile:(NSString*)filePath
{
    BOOL ret = YES;
    
    if (filePath && filePath.length >0 ) {
        
        
        NSFileManager *fileMgr = [NSFileManager defaultManager];
        NSError * error = nil;
        NSDictionary * att =[fileMgr attributesOfItemAtPath:filePath error:&error];
        
        YvDebugLog(@"file fileSize = %lld",[att fileSize]);
        
        
        ret = [fileMgr removeItemAtPath:filePath error:&error];
        if (error) {
            YvDebugLog(@"删除文件出错: %@",filePath);
        }
    }//
    
    
    return ret;
}


#pragma mark - 发送文本消息

//按发送按钮触发
- (IBAction)sendTextAction:(id)sender {
    
    if (self.textField.text.length == 0) {
        return;
    }
    
    if (sender) {
        NSLog(@" 发送按钮被按。。。发送文本消息");
    }
    

    NSString * message = self.textField.text;
    NSUInteger uniqueId = [self createUniqueId];
    [self UI_addSendTextMessage:self.textField.text sendTime:[NSDate date]  uniqueId:uniqueId];
    self.textField.text = @"";
    
    NSString * uniqueIdStr = [NSString stringWithFormat:@"%lu",uniqueId];
    
    [self __ChatManage_sendTextMessage:message expand:uniqueIdStr];//发送消息到服务器
    
    [self.textField resignFirstResponder];
}

//按键盘右下角的 send（发送键）
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"键盘发送键被按。。。发送文本消息");
    [self sendTextAction:nil];
    
    return YES;
}

#pragma mark - //------------------------------实时语音 上麦/下麦---------------------------------//
-(void)realTimeVoice_SwitchValueChanged
{
    if (self.realTimeVoiceSwitch.on) {
        
        [self realTimeVoice_StartAction];
    }
    else
    {
        [self realTimeVoice_StopAction];
    }
    
}


//启动(上麦)实时语音
-(void)realTimeVoice_StartAction
{
    //有语音播放，先停掉播放
    if ([self __YvAudioTools_isPlaying]) {
        [self __YvAudioTools_stopPlayAudio];
    }
    
    //启动实时语音---》上麦操作
    NSLog(@"实时语音按钮 被按....启动实时语音->发起上麦操作");
   [self __ChatManage_ChatMic:YES expand:@"czw"];
 //   [[YvChatManage sharedInstance] ChatMicWithTimeLimit:10 expand:@""];
    
}

//停止(下麦)实时语音
-(void)realTimeVoice_StopAction
{
    //停止实时语音--->下麦操作
    NSLog(@"实时语音按钮 被放开....关闭实时语音->发起下麦操作");
    [self __ChatManage_ChatMic:NO expand:@""];
}

#pragma mark - /----------------------YvAudioTools(录音,播放工具类)-----------------/

#pragma mark YvAudioTools初始化
//YvAudioTools初始化
-(void)__YvAudioTools_Init
{
    self.audioTools = [[YvAudioTools alloc] initWithDelegate:self];
}

#pragma mark 开始录制
//开始录制
-(void)__YvAudioTools_StartRecord
{
    //czw
    [self.avAudioPlayer pause];
    //czw
    
    NSLog(@" start record....");
    /**UI显示:录制提示图标显示**/
    self.voiceRecordHUD = [[XHVoiceRecordHUD alloc] initWithFrame:CGRectMake(0, 0, 140, 140)];
    [self.voiceRecordHUD startRecordingHUDAtView:self.view];
    
    /**开始录制**/
    NSDateFormatter * datefmt =[[NSDateFormatter alloc]init];
    [datefmt setDateFormat:@"yyyy-MM-dd-HH:mm:ss.SSS"];
    NSString * dateamr = [datefmt stringFromDate:[NSDate date]];
    NSString *path = [NSTemporaryDirectory() stringByAppendingFormat:@"%@.amr",dateamr];
    self.audioTools.RecordfilePath = path;
    
    [self.audioTools startRecord];
}

#pragma mark 停止录制
//停止录制
-(void)__YvAudioTools_StopRecord
{

    
    NSLog(@" stop record....");
    
    /**UI关闭:录制提示图标关闭**/
    [self.voiceRecordHUD stopRecordCompled:^(BOOL fnished) {
    }];
    
    /**停止录制**/
    [self.audioTools stopRecord];
    
    
    
    
    
    //czw
    if (! self.avAudioPlayer.isPlaying) {
        NSLog(@"停止播放了。。。。。");



//        _avAudioPlayer.volume = 1;
        //预播放
        [self.avAudioPlayer play];
        

    }else
    {
        NSLog(@"正在播放中。。。。。");
    }
    
    //czw
}
//czw
-(void)playMP3
{
    [[AVAudioSession sharedInstance] setActive:YES error:nil];

    BOOL pp =[[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:0 error:nil];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [[AVAudioSession sharedInstance] overrideOutputAudioPort:AVAudioSessionPortOverrideSpeaker error:nil];

    });

    NSString *string = [[NSBundle mainBundle] pathForResource:@"2012" ofType:@"mp3"];//@"background-music-aac" ofType:@"wav"];

//    NSString *string = [[NSBundle mainBundle] pathForResource:@"2012" ofType:@"mp3"];//@"background-music-aac" ofType:@"wav"];
    //把音频文件转换成url格式
    NSURL *url = [NSURL fileURLWithPath:string];
    //初始化音频类 并且添加播放文件
    if (!self.avAudioPlayer) {
        self.avAudioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
    }
    
    
    BOOL exist = [[NSFileManager defaultManager] fileExistsAtPath:string];
    
    NSLog(@" url = %@, exist = %d, self.avAudioPlayer = %@", url, exist, self.avAudioPlayer);
    //设置代理
    //avAudioPlayer.delegate = self;
    
    //设置初始音量大小
    _avAudioPlayer.volume = 1;
    
    //设置音乐播放次数  -1为一直循环
    self.avAudioPlayer.numberOfLoops = -1;
    //预播放
    [self.avAudioPlayer prepareToPlay];
    
    [self.avAudioPlayer play];
}
//czw 2016 - 3 -6

#pragma mark 判断当前是否正在录制
//判断当前是否正在录制
-(BOOL)__YvAudioTools_IsRecording
{
    return [self.audioTools isRecording];
}

#pragma mark 播放语音文件
//播放语音文件
-(int)__YvAudioTools_playAudio:(NSString *)voiceFilePath
{
   return  [self.audioTools playAudio:voiceFilePath];
    
}
#pragma mark 播放语音url(内部实现下载，播放,播放一次后保存在缓存文件区)
//播放语音url(内部实现下载，播放,播放一次后保存在缓存文件区)
-(int)__YvAudioTools_playOnlineAudio:(NSString *)voiceUrl
{
   return  [self.audioTools playOnlineAudio:voiceUrl];
}

//播放语音url(内部实现下载，播放,播放一次后保存在缓存文件区)  +  带下载进度回调 和 下载完成回调
-(int)__YvAudioTools_playOnlineAudio:(NSString *)fileurl
                          downloadProgress:(void (^)(int totalSize, int progressSize, NSString * fileurl, int playSequenceId))downloadProgressBlock
                          downloadFinished:(void (^)(int result, NSString * errMsg, NSString * fileurl, int playSequenceId))downloadFinishedBlock
{
    return [self.audioTools playOnlineAudio:fileurl downloadProgress:downloadProgressBlock downloadFinished:downloadFinishedBlock];
}

#pragma mark 停止播放
//停止播放
-(void)__YvAudioTools_stopPlayAudio
{
    [self.audioTools stopPlayAudio];
}

#pragma mark 判断是否正在播放
//判断是否正在播放
-(BOOL)__YvAudioTools_isPlaying
{
    return [self.audioTools isPlaying];
}


#pragma mark - /----------------------YvChatManageVideoDelegate(YvChatManage+Video的回调函数)-----------------/
//用户登陆视频结果回调 result:0 成功，其他失败, msg 失败信息 users 当前已登陆视频的用户信息(YvVideoUserInfo)   type;//0表示禁掉（不可以上传视频，被拉黑），1表示取消禁掉（取消黑名单，可以上传视频）,2表示警告中（你上传的视频内容不健康，警告你或直接拉黑你）
-(void)onChatManage:(YvChatManage *)sender videoLoginResp:(int)result msg:(NSString *)msg users:(NSArray *)users type:(int)type
{
    if (result==0) {
        //自己管理视频的连接
        if (!_isAutoConnectVideo)
        {
//            [[YvChatManage sharedInstance] startVideoPlay_position:[self.videoPostion integerValue] videoCount:[self.videoNum integerValue]];
        }
        YvDebugLog(@"视频连接成功");//YvChatManage登入房间成功后，在进行视频连接请求，这个回调就是视频连接请求的回调。
    }
}
//其他用户登陆视频房间 的登陆状态通知 loginState 0表示离开，1表示进来
-(void)onChatManage:(YvChatManage *)sender otherUser:(UInt32)yunvaId position:(UInt8)position LoginState:(UInt8)loginState
{
    NSString *str=nil;
    if (loginState==0)
    {
        str = @"退出视频房间";//这里说@“退出视频房间”，是因为sdk内部进行了处理：即用户调用了YvChatManage的 Logout方法，sdk会自动调用视频退出接口
    }
    else
    {
        str = @"进入视频房间";
    }
    YvDebugLog(@"%@",[NSString stringWithFormat:@"［yunvaId:%@ ,position:%@ ,%@］",@(yunvaId),@(position),str]);
}
#pragma mark - /----------------------YvAudioToolsDelegate(YvAudioTools的回调函数)-----------------/
#pragma mark 语音录制结束-回调
/*!
 @callback
 @brief 功能：语音录制结束回调
 @param audiotools -- 接口对象
 @param voiceData -- 语音录制数据
 @param voiceDuration --语音时长
 @param filePath -- 语音录制数据保存文件
 @result YES:正在语音录制  NO:当前没有语音录制
 */
-(void)AudioTools:(YvAudioTools *)audiotools RecordCompleteWithVoiceData:(NSData *)voiceData voiceDuration:(int)voiceDuration filePath:(NSString *)filePath
{
    /**UI操作:关闭录音提示图标**/
    [self.voiceRecordHUD stopRecordCompled:^(BOOL fnished) {
    }];
    
    /*****UI界面显示:*****/
    NSString * text= nil;;
    if (self.recognizeEnable) {
        text = @"(正在语音识别中...)";
    }
    
    NSUInteger uniqueId = [self createUniqueId];
   YAChatMessageVoice *voiceMsg  =  [self UI_addSendVoiceMessageWithVoiceUrl:nil voiceFilePath:filePath voiceDuration:voiceDuration text:text sendTime:[NSDate date]  uniqueId:uniqueId];
    NSString * uniqueIdString = [NSString stringWithFormat:@"%ld",uniqueId];
    
    
    if (self.recognizeEnable) {//需要识别   发送富消息：发送语音＋识别文本
        
        
        /*****上传语音文件 + 语音识别*****/
        __weak __typeof(&*self)weakSelf = self;
        [self __ChatManage_httpVoiceRecognizeReqWithVoiceFilePath:filePath voiceDuration:voiceDuration expand:uniqueIdString responseCallback:^(int result, NSString *errMsg, NSString *text, NSString *voiceDownloadUrl, NSString *voiceFilePath, int voiceDuration, NSString *expand, id reserve) {
            
            __strong __typeof(&*weakSelf)strongSelf = weakSelf;
            if (!strongSelf) {
                return;
            }
            
            // 回调函数调用
            NSLog(@"result = %d, errMsg = %@, 语音识别出文本:text=%@, 语音文件下载url voiceDownloadUrl = %@, expand = %@",
                  result, errMsg, text, voiceDownloadUrl, expand);
            
            if ((voiceDownloadUrl && voiceDownloadUrl.length > 0)
                && (text && text.length >0) ) { //语音上传  语音识别都成功了
                
                voiceMsg.voiceUrl = voiceDownloadUrl;
                [strongSelf deleteFile:filePath];//删除已上传的文件
                
                // 发送富消息【文本+语音】
                [strongSelf __ChatManage_sendRichMessageWithTextMsg:text voiceUrl:voiceDownloadUrl voiceDuration:voiceDuration expand:uniqueIdString];
                
                [strongSelf updateVoiceRecognizeText:text UniqueId:uniqueId];
                
                
            }
            else if (voiceDownloadUrl && voiceDownloadUrl.length > 0) //语音上传 成功  语音识别回复为空
            {
                voiceMsg.voiceUrl = voiceDownloadUrl;
                [strongSelf deleteFile:filePath];//删除已上传的文件
                
                // 发送 纯语音 消息 (没有识别出文字，也要发送语音消息)
                [strongSelf __ChatManage_sendVoiceMessageWithVoiceUrl:voiceDownloadUrl voiceDuration:voiceDuration expand:uniqueIdString];
                
                if (kResultSuccess != result) {
                    
                    NSString * msg = [NSString stringWithFormat:@"(语音识别失败:result=%d, errMsg=%@)",result,errMsg];
                    [strongSelf updateVoiceRecognizeText:msg UniqueId:uniqueId];
                    
                    
                }
            }
            else if (kResultSuccess != result ) //语音上传 语音识别 都失败了
            {
                NSUInteger uniqueId =  expand.intValue;
                [strongSelf closeActivityIndicatorWithUniqueId:uniqueId];
                
                NSString * msg = [NSString stringWithFormat:@"result = %d, errMsg = %@", result, errMsg];
                [strongSelf showSendErrorWithUniqueId:uniqueId];
                
                [strongSelf showAlertViewTitle:@"[上传语音+语音识别]失败" message:msg];
                
                [strongSelf updateVoiceRecognizeText:@"[上传语音+语音识别]失败" UniqueId:uniqueId];
                
            }
        }];
    }
    else
    {
        /*****上传语音文件*****/
        __weak __typeof(&*self)weakSelf = self;
        [self __ChatManage_uploadVoiceFile:filePath success:^(NSString *voiceUrl) {
            
            __strong __typeof(&*weakSelf)strongSelf = weakSelf;
            if (!strongSelf) {
                return;
            }
            voiceMsg.voiceUrl = voiceUrl;
            [strongSelf deleteFile:filePath];//删除已上传的文件
            //发送纯语音消息
            [strongSelf __ChatManage_sendVoiceMessageWithVoiceUrl:voiceUrl voiceDuration:voiceDuration expand:uniqueIdString];
            
        } failure:^(NSError *error) {
            
            __strong __typeof(&*weakSelf)strongSelf = weakSelf;
            if (!strongSelf) {
                return;
            }
            
            [strongSelf closeActivityIndicatorWithUniqueId:uniqueId];
            
            NSString * msg = [NSString stringWithFormat:@"网络错误code=%d,", error.code];
            [strongSelf showSendErrorWithUniqueId:uniqueId];
            
            [strongSelf  showAlertViewTitle:@"【上传语音文件】失败" message:msg];
            
        }];
    }
        
}

#pragma mark 语音播放结束-回调
/**播放声音完毕*/
-(void)AudioToolsPlayComplete:(YvAudioTools *)audiotools WithResult:(int)result PlaySequenceId:(int)playSequenceId
{
    /**播放已停止的相关处理**/
    [self playFinishedHandle:playSequenceId];
    
    if (kResultSuccess != result) {
        
        if (-3 == result) {
            
            YvDebugLog(@" 播放失败:语音文件下载失败");
            [Utilities showTextHUDMaintain2Seccond:@"播放失败:语音文件下载失败"];
        }
    }
}

#pragma mark 语音录制峰值和平均值-回调
/**当开启播放声音和录音的计量检测,返回录音的峰值和平均值*/
-(void)AudioTools:(YvAudioTools *)audiotools RecorderMeteringPeakPower:(float)peakPower AvgPower:(float)avgPower
{
    if (self.voiceRecordHUD) {
        YvDebugLog(@"peakPower = %f,  avgPower = %f", peakPower, avgPower);
        self.voiceRecordHUD.peakPower = peakPower;
    }
}


#pragma mark - /----------------------YvChatManage(SDK初始化 实时语音 收发消息 语音识别+文件上传)-----------------/

#pragma mark 初始化
-(void)__ChatManage_initWithAppId:(NSString *)appid isTest:(BOOL)isTest
{
    //注意在这里[YvChatManage sharedInstance]中已经对YvRealTimeAudio进行初始化，也就是对AUGraph进行初始化
    

    //设置第三方账号
//    [YvChatManage setAccessServer:@"116.251.231.17"];
     [[YvChatManage sharedInstance] SetInitParamWithAppId:appid istest:isTest];//初始化
//    [[YvChatManage sharedInstance] SetInitParamWithEnvironment:2 AppId:appid];//海外
 //   [[YvChatManage sharedInstance] SetInitParamWithAppId:appid istest:isTest isServerCompose:YES];
    
    
    
    
    [YvChatManage sharedInstance].delegate = self;//设置回调代理(即被调回调函数的对象)
//    [YvChatManage sharedInstance].videoDelegate=self;//设置视频连接的回调代理。
    
//    
//    [[YvDnsManage sharedInstance] setUpWithDelegate:self appId:appid];
//    [[YvDnsManage sharedInstance] requestSdkIdDomain];
//    NSMutableArray* array = [[NSMutableArray alloc] init];
//    [array addObject:@"p_access"];
//    [[YvDnsManage sharedInstance] requestAPPDomainListWithSdkId:@"100076" appId:@"1000921" kindNames:array];
//    [[YvDnsManage sharedInstance] reportInvalidDomain:@"test" sdkId:@"100076" appId:@"1000921" kindName:@"p_access"];
    
}

#pragma mark 登录
//登录-内部自动注册一个账号, seq:房间id, seq值 一样,表示登录同一个房间，同一个房间才能互相发消息和实时语音
-(void)__ChatManage_LoginWithSeq:(NSString *)seq
{
    YvDebugLog(@"视频参数：hasVideo=%d   ,position=%ld    ,videoCount=%d",self.isHaveView,(long)[self.videoPostion integerValue],[self.videoNum intValue]);
//    [self __ChatManage_LoginBindingWithTT:@"" seq:@""];
    
    [[YvChatManage sharedInstance] LoginWithSeq:seq hasVideo:self.isHaveView position:[self.videoPostion integerValue] videoCount:[self.videoNum intValue]];
    
    //自己管理视频的连接
    if (!_isAutoConnectVideo)
    {
        //
        [YvChatManage sharedInstance].isAutoConnectVideo =NO;

    }
}

//第三方登录-根据tt绑定一个账号, seq:房间id, seq值 一样,表示登录同一个房间，同一个房间才能互相发消息和实时语音
-(void)__ChatManage_LoginBindingWithTT:(NSString *)tt seq:(NSString *)seq
{
    seq = @"1393440003";
    NSString *ttt = [NSString stringWithFormat:@"{\"uid\":\"%@\",\"nickname\":\"%@\"}",@"1300005",@"1300005"];
//     NSString *ttt = [NSString stringWithFormat:@"uid=%@&nickname=%@}",@"16d69",@"江南"];
//    [[YvChatManage sharedInstance] LoginBindingWithTT:ttt seq:@"55" hasVideo:self.isHaveView position:[self.videoPostion integerValue] videoCount:[self.videoNum intValue]];
    
    
    [[YvChatManage sharedInstance] LoginBindingWithTT:ttt seq:seq hasVideo:self.isHaveView position:[self.videoPostion integerValue] videoCount:[self.videoNum intValue]];
}

#pragma mark 注销
-(void)__ChatManage_Logout
{
    //自己管理视频的连接
    if (!_isAutoConnectVideo)
    {
        //退出房间前 先关闭视频解码器，断开视频连接
//        [[YvChatManage sharedInstance] stopVideoPlay];
//        [[YvChatManage sharedInstance] chatvideo_cancelConnectToNestHost];
    }
    [[YvChatManage sharedInstance] Logout];
}


#pragma mark 获取历史消息
-(void)__ChatManage_queryHistoryMsgReqWithPageIndex:(int)pageIndex PageSize:(int)pageSize
{
//    [[YvChatManage sharedInstance] queryHistoryMsgReqWithPageIndex:pageIndex PageSize:pageSize];
}

-(void)ChatManage:(YvChatManage *)sender GetTroopsListResp:(int)result msg:(NSString*)msg userList:(NSMutableArray*)userList
{
    NSString* str1 = @"";
    for (NSString* str in userList) {
        
        str1 = [str1 stringByAppendingString:str];
    }
    _ExceptionLabel.text = [NSString stringWithFormat:@"%@",str1];
}

-(void)ChatManage:(YvChatManage *)sender ChatMicStateNotify:(TroopsChangeNotify*)micStateNotify
{
    NSLog(@"");
}
#pragma mark 发送文本消息
-(void)__ChatManage_sendTextMessage:(NSString *)textMessage expand:(NSString *)expand
{
     [[YvChatManage sharedInstance] sendTextMessage:textMessage expand:expand];
}

#pragma mark 上传语音文件
-(void)__ChatManage_uploadVoiceFile:(NSString *)voiceFilePath
                            success:(void (^)(NSString * voiceUrl))success
                            failure:(void (^)( NSError *error))failure
{
    E_UploadFile_Retain_Time fileRetainTimeType = kUploadFile_Retain_Time_2_week;//上传文件保存时间 2星期
    
    [[YvChatManage sharedInstance] uploadVoiceMessage:voiceFilePath retainTimeType:fileRetainTimeType success:success failure:failure];
}

#pragma mark 发送纯语音消息
-(void)__ChatManage_sendVoiceMessageWithVoiceUrl:(NSString *)voiceUrl voiceDuration:(int)voiceDuration expand:(NSString *)expand
{
    [[YvChatManage sharedInstance] sendVoiceMessageWithVoiceUrl:voiceUrl voiceDuration:voiceDuration expand:expand];
}

#pragma mark 上传文件+语音识别
-(void)__ChatManage_httpVoiceRecognizeReqWithVoiceFilePath:(NSString *)voiceFilePath //语音文件路径
                                             voiceDuration:(int)voiceDuration //语音时长 单位:毫秒
                                                    expand:(NSString *)expand //会话扩展字段(回调会带回一样的值)
                                          responseCallback:(void (^)(int result, NSString * errMsg, NSString * text, NSString * voiceDownloadUrl, NSString * voiceFilePath, int voiceDuration, NSString * expand, id reserve))responseCallback
{
    E_UploadFile_Retain_Time fileRetainTimeType = kUploadFile_Retain_Time_2_week;//上传文件保存时间 2星期
    
    [[YvChatManage sharedInstance] httpVoiceRecognizeReqWithRecognizeLanguage:self.recognizeLanguage OutputLanguageType:self.outputTextLanguageType voiceFilePath:voiceFilePath voiceDuration:voiceDuration retainTimeType:fileRetainTimeType voiceUrl:nil expand:expand responseCallback:responseCallback];
}

#pragma mark 发送富消息[语言+文本]消息
-(void)__ChatManage_sendRichMessageWithTextMsg:(NSString *)text voiceUrl:(NSString *)voiceUrl voiceDuration:(int)voiceDuration expand:(NSString *)expand
{
    [[YvChatManage sharedInstance] sendRichMessageWithTextMsg:text voiceUrl:voiceUrl voiceDuration:voiceDuration expand:expand];
}


#pragma mark  实时语音接口
/**聊天中的实时语音上麦，下麦*/
-(void)__ChatManage_ChatMic:(BOOL)onoff expand:(NSString *)expand
{
    [[YvChatManage sharedInstance] ChatMic:onoff expand:expand];
    
    if (!onoff) {
        
        [self.voiceRecordHUD stopRecordCompled:^(BOOL fnished) {
        }];
    }
}

/**设置是否暂停【播放】实时语音聊天*/
-(void)__ChatManage_setPausePlayRealAudio:(BOOL)isPasue
{
    [[YvChatManage sharedInstance] setPausePlayRealAudio:isPasue];
}

/**获取当前是否已经暂停【播放】实时语音*/
-(BOOL)__ChatManage_isPausePlayAudio
{
    return [[YvChatManage sharedInstance] isPausePlayAudio];
}

/**设置麦模式，modeType:0自由模式，1抢麦模式，2指挥模式 , 见枚举类型:E_MicModeType*/
-(void)__ChatManage_MicModeSettingWithmodeType:(UInt8)modeType
{
    [[YvChatManage sharedInstance] MicModeSettingWithmodeType:modeType];
}

/**获取当前是否是上麦状态**/
-(BOOL)__YvAudioTools_getCurrentMicState
{
    return [[YvChatManage sharedInstance] getCurrentMicState];
}

#pragma mark - /----------------------YvChatManageDelegate (YvChatManage 的回调函数)-----------------/

#pragma mark 断网-回调
-(void)ChatManage:(YvChatManage *)sender OnConnectFail:(NSString *)desc
{
    YvDebugLog(@"%@",desc);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (showHud) {
            [Utilities hideHUDForView:self.view];
            
            [Utilities showTextHUDMaintain2Seccond:desc];//czw

        }
    });
}

#pragma mark 网络自动重连-回调
/*!
 @callback 该函数为回调函数 add by huangzhijun 2015.1.23
 @brief 在网络异常(如:wifi-->3G, 3G-->wifi,无网络-->3G/wifi),开始自动重新登录
 @param tryReLoginTimes 重新登录尝试次数
 @result
 */
-(void)ChatManage:(YvChatManage *)sender BeginAutoReLoginWithTryTimes:(NSUInteger)tryReLoginTimes
{
    [Utilities hideHUDForView:self.view];
    NSString * str = [NSString stringWithFormat:@"网络第%lu次自动重登陆..",tryReLoginTimes];
    YvDebugLog(@"%@",str);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (showHud) {
            [Utilities showTextHUDMaintain2Seccond:str];  //czw

        }
    });
}

#pragma mark 认证结果-回调
/**登录返回LoginWithSeq 认证 结果回调 (内部认证成功会自动调进入房间操作，全部成功，会回调下面的登录结果 回调)**/
-(void)ChatManage:(YvChatManage *)sender AuthResp:(int)result msg:(NSString *)msg
{
    if (kResultSuccess == result) {
        
        NSLog(@" 认证成功,可以http 语音识别+语音文件上传功能可以使用了 ");
    }
    
}

#pragma mark 登录(认证+进入房间)结果-回调
-(void)ChatManage:(YvChatManage *)sender LoginResp:(int)result msg:(NSString *)msg yunvaid:(UInt64)yunvaid MicModeType:(E_MicModeType)modeType leaderId:(UInt64)leaderId isLeader:(BOOL)isLeader
{
    [Utilities hideHUDForView:self.view];
    
    if (kResultSuccess == result) {
        YvDebugLog(@" Login success,  yunvaid = %d, modeType = %d leaderId = %d, isLeader = %d !!!", yunvaid, modeType, leaderId, isLeader);
        
        self.yunvaId = yunvaid;
        _realTimeVoice_MicModeType = modeType;
        
        self.navigationItem.title = [NSString stringWithFormat:@"%@(yunvaId=%lld)",@"房间", yunvaid];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (showHud) {
                [Utilities showTextHUDMaintain2Seccond:@"登录成功!!!"];//czw
            }
        });
        YvDebugLog(@"登录成功!!!");
//        [self realTimeVoice_StopAction];//test
        if (!_isHistoryMessageLoaded) {
            [self __ChatManage_queryHistoryMsgReqWithPageIndex:0 PageSize:20];//获取20条历史消息
        }
        
        
        //自己管理视频的连接
        if (!_isAutoConnectVideo)
        {
            //登入房间成功后发起视频的连接 视频连接成功后进行视频编码器的连接（YvChatManageVideoDelegate）
 //           [[YvChatManage sharedInstance]  chatVideo_ConnectToNetHost];
        }
        
       // [self __ChatManage_MicModeSettingWithmodeType:0];//test
        
    }
    else
    {
        YvDebugLog(@" Login fail :%@",msg);
        [Utilities showTextHUDMaintain2Seccond:@"登录失败"];
    }
    
    
}
-(void)ChatManage:(YvChatManage *)sender LoginResp:(int)result msg:(NSString *)msg yunvaid:(UInt64)yunvaid
{
    YvDebugLog(@"");
}
#pragma mark 注销结束-回调
/**注销返回*/
-(void)ChatManage:(YvChatManage *)sender LogoutResp:(int)result msg:(NSString *)msg
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark 文本发送成功-回调
//文本发送成功
-(void)ChatManage:(YvChatManage *)sender SendTextMessageSuccessWithExpand:(NSString*)expand
{
    NSUInteger uniqueId =  expand.intValue;
    [self closeActivityIndicatorWithUniqueId:uniqueId];
}

#pragma mark 文本发送失败-回调
/**文本发送失败回调*/
-(void)ChatManage:(YvChatManage *)sender SendTextMessageError:(int)result msg:(NSString *)msg expand:(NSString*)expand
{
    NSUInteger uniqueId =  expand.intValue;
    [self closeActivityIndicatorWithUniqueId:uniqueId];
    
    if (kResultSuccess != result) {
        
        NSString * errMsg = [NSString stringWithFormat:@"发送文本失败:%@",msg];
        YvDebugLog(@"发送文本失败");
        [Utilities showTextHUDMaintain2Seccond:errMsg];
        [self showSendErrorWithUniqueId:uniqueId];
    }
    
    
}

#pragma mark 接收到文本消息-通知回调
/**接收到文本-通知*/
-(void)ChatManage:(YvChatManage *)sender TextMessageNotify:(TextMessageNotify *)TextMessageNotify
{
    //收到 文本消息，插入显示
    [self UI_addRecivedTextMessage:TextMessageNotify];
}


#pragma mark 发送语音结果-回调
/**发送语音留言返回,发送时会先上传到服务器并返回地址,故将上传的路径、时间返回*/
-(void)ChatManage:(YvChatManage *)sender SendVoiceMessageResp:(int)result msg:(NSString *)msg voiceUrl:(NSString *)voiceUrl voiceDuration:(UInt64)voiceDuration filePath:(NSString *)filePath expand:(NSString *)expand
{
    NSUInteger uniqueId =  expand.intValue;
    [self closeActivityIndicatorWithUniqueId:uniqueId];
    
    if (kResultSuccess != result) {
        
        NSString * errMsg = [NSString stringWithFormat:@"发送语音失败:%@",msg];
        YvDebugLog(@"发送语音失败")
        [Utilities showTextHUDMaintain2Seccond:errMsg];
        [self showSendErrorWithUniqueId:uniqueId];
    }
}

#pragma mark 收到语音消息-通知回调
/**接收到语音留言通知*/
-(void)ChatManage:(YvChatManage *)sender VoiceMessageNotify:(VoiceMessageNotify *)VoiceMessageNotify
{
    //收到 语音消息，插入显示
    [self UI_addRecivedVoiceMessage:VoiceMessageNotify];
}


/********************************begin 富消息(文本+语音)*************************************/
#pragma mark 富消息(文本+语音)发送结果-回调
/*发送文本+语音富消息返回，发送时会先上传语音到服务器并返回地址 add by huangzhijun 2014.12.8*/
-(void)ChatManage:(YvChatManage *)sender SendRichMessageResp:(int)result msg:(NSString *)msg textMsg:(NSString *)textMsg  voiceUrl:(NSString *)voiceUrl voiceDuration:(UInt64)voiceDuration filePath:(NSString *)filePath expand:(NSString *)expand
{
    NSUInteger uniqueId =  expand.intValue;
    [self closeActivityIndicatorWithUniqueId:uniqueId];
    
    if (kResultSuccess != result) {
        
        NSString * errMsg = [NSString stringWithFormat:@"发送富消息(文本+语音)失败:%@",msg];
        [Utilities showTextHUDMaintain2Seccond:errMsg];
        [self showSendErrorWithUniqueId:uniqueId];
    }
}

#pragma mark 收到富消息(文本+语音)-通知回调
/** 文本+语音留言 通知 (一般用于语音文字识别功能的通知) add 2014.12.5**/
-(void)ChatManage:(YvChatManage *)sender RichMessageNotifyWithTextMessage:(TextMessageNotify *)TextMessageNotify VoiceMessage:(VoiceMessageNotify *)VoiceMessageNotify;
{
    //收到 [文本+语音]消息，插入显示
    [self UI_adddRecivedRichMessage:TextMessageNotify voiceMessageNotify:VoiceMessageNotify];
}
/*********************************end 富消息(文本+语音)*************************************/


#pragma mark 上下麦-回调
/**上下麦返回*/
-(void)ChatManage:(YvChatManage *)sender ChatMicResp:(int)result msg:(NSString *)msg onoff:(BOOL)onoff
{
    YvDebugLog(@"result = %d, msg = %@, onoff = %d", result, msg, onoff);//日志打印
    if (result == 0) {
        if (onoff) {
            
            self.voiceRecordHUD = [[XHVoiceRecordHUD alloc] initWithFrame:CGRectMake(0, 0, 140, 140)];
            [self.voiceRecordHUD startRecordingHUDAtView:self.view];
            
            //上麦成功，可以实时语音了
            [Utilities showTextHUD:@"上麦成功，可以实时语音了" andView:self.view maintainTime:1];

        }
        else
        {
            [self.voiceRecordHUD stopRecordCompled:^(BOOL fnished) {
            }];
            
            //下麦成功
            [Utilities showTextHUD:@"下麦成功，取消实时录音" andView:self.view maintainTime:1];

        }
    }
    else
    {
        self.realTimeVoiceSwitch.on = NO;
        
        [self.voiceRecordHUD stopRecordCompled:^(BOOL fnished) {
        }];
        
        //上麦操作失败，可能有人已上麦
        NSString * micModeString = nil;
        switch (_realTimeVoice_MicModeType) {
            case kMicModeType_freedomMode://0:自由模式:上麦即可说话，大家都可以同时说话
                micModeString = @"自由模式";
                break;
            case kMicModeType_competitionMode://1:抢麦模式，谁抢到麦，谁就能说话，其他人就只能听，然后他下麦后，谁第一个去抢麦谁就能抢到。
                micModeString = @"抢麦模式";
                break;
            case kMicModeType_chairmanMode://2:指挥模式(或叫主席模式):只有他自己能说话，其他人都不能说话,也无法抢麦,只能听
                micModeString = @"指挥模式(或叫主席模式)";
                
                break;
            default:
                break;
        }
        
        NSString * errMsg = [NSString stringWithFormat:@"(1)服务器返回错误信息:%@, (2)当前麦模式是:%@",msg,micModeString];
       // [Utilities showTextHUD:[NSString stringWithFormat:@"上麦失败:%@, 当前麦模式是:%@",msg,micModeString] andView:self.view maintainTime:2];
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:@"上麦失败" message:errMsg delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles:nil];
        
        [alertView show];
    }

}

#pragma mark 实时语音相关-回调
/**实时语音错误返回，只有发送失败才会收到回调，注意音频是发送是频繁的，出现错误时此事件是一连串的*/
-(void)ChatManage:(YvChatManage *)sender SendRealTimeVoiceMessageError:(int)result msg:(NSString *)msg
{
    
}

/**实时语音通知*/
-(void)ChatManage:(YvChatManage *)sender RealTimeVoiceMessageNotifyWithYunvaId:(UInt32)yunvaid chatroomId:(NSString *)chatroomId expand:(NSString *)expand
{
    
}

#pragma mark 实时语音--播放语音的峰值和平均值-回调
/**当开启播放声音和录音的计量检测,返回实时语音或自动播放的峰值和平均值*/
-(void)ChatManage:(YvChatManage *)sender PlayMeteringPeakPower:(float)peakPower AvgPower:(float)avgPower
{
    
}

#pragma mark 实时语音--录音的语音的峰值和平均值-回调
/**当开启录音的计量检测,返回实时录音的峰值和平均值*/
-(void)ChatManage:(YvChatManage *)sender RecorderMeteringPeakPower:(float)peakPower AvgPower:(float)avgPower
{
    self.voiceRecordHUD.peakPower = peakPower;
    _ExceptionLabel.text = [NSString stringWithFormat:@"peak:%f avg:%f",peakPower,avgPower];
    YvDebugLog(@"%@",_ExceptionLabel.text);
}


#pragma mark 用户被踢出房间-回调
/**请出房间回调*/
-(void)ChatManage:(YvChatManage *)sender KickOutNotifyWithmsg:(NSString *)msg
{
    YvDebugLog(" KickOutNotifyWithmsg msg = %@",msg);
}

#pragma mark 用户状态改变-回调
/**用户状态改变回调*/
-(void)ChatManage:(YvChatManage *)sender UserStateNotify:(UserStateNotify *)userStateNotify
{
    YvDebugLog(@" userStateNotify");
}

#pragma mark 设置麦模式返回-回调
/**设置麦模式返回*/
-(void)ChatManage:(YvChatManage *)sender MicModeSettingResp:(int)result msg:(NSString *)msg
{
    if (kResultSuccess == result) {
        
        YvDebugLog(@"设置麦模式成功");
        [Utilities showTextHUDMaintain2Seccond:@"设置麦模式成功"];
    }
    else
    {
        [Utilities showTextHUDMaintain2Seccond:@"设置麦模式失败"];
    }
}

#pragma mark 麦模式更改-通知回调
/**麦模式更改通知*/
-(void)ChatManage:(YvChatManage *)sender MicModeChangeNotify:(MicModeChangeNotify *)micModeChangeNotify
{
    YvDebugLog(@"收到麦模式被修改通知 modeType = %d, isLeader = %d", micModeChangeNotify.modeType, micModeChangeNotify.isLeader);
    _realTimeVoice_MicModeType = micModeChangeNotify.modeType;
    //[Utilities showTextHUDMaintain2Seccond:@"收到麦模式被修改通知"];
    
}

#pragma mark 检测当前系统的音量-回调
/**检测当前系统的音量*/
-(void)ChatManage:(YvChatManage *)sender CurrentSystemVolume:(float)volume
{
    
}

- (void)ChatManage:(YvChatManage *)sender NetWorkDelay:(UInt64)delay
{
    _timeDelay.text = [NSString stringWithFormat:@"%llu毫秒",delay];
}
#pragma mark 获取聊天历史记录接口-回调
/**
 获取聊天历史记录接口回调
 @param roomMode - 2:主播模式、1:抢麦模式 4:麦序模式
 @param result -- 返回码:0 - 成功, 非0 - 失败
 @param msg -- 错误消息
 @param historyMsgArray -- 聊天历史记录 元素类型: TextMessageNotify对象(文本对象)  或者  VoiceMessageNotify对象(语音对象)  或者  RichMessageNotify对象(文本+语音)
 */
-(void)ChatManage:(YvChatManage *)sender QueryHistoryMsgResp:(int)result msg:(NSString*)msg historyMsgArray:(NSArray*)historyMsgArray
{
    
    if (_isHistoryMessageLoaded) {
        NSLog(@"历史消息已经加载过了，本次应该是断网重新登录");
        return;
    }
    
    _isHistoryMessageLoaded = YES;
    
    
    if(kResultSuccess == result
       && historyMsgArray
       && historyMsgArray.count >0)
    {
        for (NSObject * msg in historyMsgArray) {
            
            if ([msg isKindOfClass:[TextMessageNotify class]]) {
                
                TextMessageNotify * textMsg = (TextMessageNotify *)msg;
                
                
                if (self.yunvaId == textMsg.yunvaId) {
                    
                    NSUInteger uniqueId = [self createUniqueId];
                    NSDate *date = [NSDate dateWithTimeIntervalSince1970:textMsg.time];
                    [self UI_addSendTextMessage:textMsg.text sendTime:date  uniqueId:uniqueId];
                    
                    [self closeActivityIndicatorWithUniqueId:uniqueId];
                }
                else
                {
                    [self UI_addRecivedTextMessage:textMsg];
                }
            }
            else if([msg isKindOfClass:[VoiceMessageNotify class]])
            {
                //[self UI_addRecivedVoiceMessage:msg];
                
                VoiceMessageNotify * voiceMsg = (VoiceMessageNotify *)msg;
                
                if (self.yunvaId == voiceMsg.yunvaId) {
                    NSUInteger uniqueId = [self createUniqueId];
                    NSDate *date = [NSDate dateWithTimeIntervalSince1970:voiceMsg.time];
                    [self UI_addSendVoiceMessageWithVoiceUrl:voiceMsg.voiceUrl voiceFilePath:nil voiceDuration:(int)voiceMsg.voiceTime text:nil sendTime:date uniqueId:uniqueId];
                    
                    [self closeActivityIndicatorWithUniqueId:uniqueId];
                    
                }
                else
                {
                    [self UI_addRecivedVoiceMessage:voiceMsg];
                }
                
            }
            else if ([msg isKindOfClass:[RichMessageNotify class]])
            {
                    RichMessageNotify * richMsg = (RichMessageNotify *)msg;
                
                    if (self.yunvaId == richMsg.voiceMsg.yunvaId)
                    {
                        VoiceMessageNotify * voiceMsg = richMsg.voiceMsg;
                        
                        NSUInteger uniqueId = [self createUniqueId];
                        NSDate *date = [NSDate dateWithTimeIntervalSince1970:voiceMsg.time];
                        [self UI_addSendVoiceMessageWithVoiceUrl:voiceMsg.voiceUrl voiceFilePath:nil voiceDuration:(int)voiceMsg.voiceTime text:richMsg.textMsg.text sendTime:date uniqueId:uniqueId];
                        
                        [self closeActivityIndicatorWithUniqueId:uniqueId];
                    }
                    else
                    {
                        [self UI_adddRecivedRichMessage:richMsg.textMsg voiceMessageNotify:richMsg.voiceMsg];
                    }
                
                
            }
            
        }
    }
    
}

-(void) ChatManage:(YvChatManage*)sender onYvExceptionRecord:(UInt64)time
{
    
//    _ExceptionLabel.text = [NSString stringWithFormat:@"过快发送%@次，间隔%llu",@(count),time];
//    count ++;
}


-(void)OnAppDnsListResponseWithResult:(NSInteger)result kindNameList:(NSMutableArray *)kindNameList error:(NSError *)error
{
    NSLog(@"");
}

-(void)OnReportErrorDomainResponse:(NSInteger)result error:(NSError *)error
{
    NSLog(@"");
}
@end
