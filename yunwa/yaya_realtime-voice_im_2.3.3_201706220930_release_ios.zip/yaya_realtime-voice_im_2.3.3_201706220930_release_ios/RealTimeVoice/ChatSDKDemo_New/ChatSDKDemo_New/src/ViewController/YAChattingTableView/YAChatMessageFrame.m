//
//  YAChatMessageFrame.m
//  ChattingRoom
//
//  Created by wind on 5/8/14.
//  Copyright (c) 2014 wind. All rights reserved.
//

#import <CoreGraphics/CoreGraphics.h>
#import "YAChatMessageFrame.h"
#import "UIImage+LK.h"
#import "SDWebImageManager.h"
//#import "YvAppConfig.h"
#import "YARichText.h"


@implementation YAChatMessageFrame
@synthesize chatMessage = _chatMessage,height;
@synthesize rectContent,rectContentText,rectNickIcon,rectNickName,rectTimeStamp,rectActivityIndicator;



- (id)initWithMesssage:(YAChatMessage *)message  delegate:(id<YAChatMessageFrameDelegate>)delegate
{
    
    if (self = [super init])
    {
        if(YAMessageStyleRight == message.messageStyle)
        {
            self.showActivityIndicator = YES;
        }
        
        self.delegate = delegate;
        [self setChatMessage:message];
    }
    
    return self;
}


- (void)caculateNickIconRect {
    YAMessageStyle style = _chatMessage.messageStyle;
    CGFloat screen_width = [UIScreen mainScreen].bounds.size.width;

    rectNickIcon =  CGRectMake(0, kContentNickIconMarginTop, kContentNickIconWH, kContentNickIconWH);
    
    if (style == YAMessageStyleLeft) {
        rectNickIcon.origin.x += kContentNickIconMarginLeftRight;
        rectNickIcon.size = CGSizeMake(kContentNickIconWH, kContentNickIconWH);
        
        //add by huangzhijun 2014.9.23 解决左边头像图标对齐问题。
        CGSize sizeNickName = [_chatMessage.nickName sizeWithAttributes:@{NSFontAttributeName:kContentInfoFont}];
        rectNickIcon.origin.y += sizeNickName.height;
        //end by huangzhijun 2014.9.23
    }
    else {
        rectNickIcon.origin.x = screen_width - kContentNickIconMarginLeftRight - kContentNickIconWH;
        rectNickIcon.size = CGSizeMake(kContentNickIconWH, kContentNickIconWH);
    }
}

- (void)caculateNickNameTimeStampRect {
    YAMessageStyle style = _chatMessage.messageStyle;

    CGSize sizeNickName = [_chatMessage.nickName sizeWithFont:kContentInfoFont];
//    CGSize sizeTimeStamp = [_chatMessage.timeStr sizeWithFont:kContentInfoFont];
    
    CGSize sizeTimeStamp = CGSizeMake(0, 0);
    
    rectNickName = CGRectMake(0,kContentInfoMarginTop , sizeNickName.width, sizeNickName.height);
    rectTimeStamp = CGRectMake(0, kContentBubbleMarginTop, sizeTimeStamp.width, sizeTimeStamp.height);
    
    if (style == YAMessageStyleLeft) {
        rectNickName.origin.x = CGRectGetMaxX(rectNickIcon) + kContentInfoMarginLeftRight;
        rectTimeStamp.origin.x = CGRectGetMaxX(rectNickName) + kContentInfoMarginLeftRight;
    }
    else {
        rectNickName.size.height = 1;
        rectTimeStamp.origin.x = CGRectGetMinX(rectNickIcon) - kContentInfoMarginLeftRight - sizeTimeStamp.width;
        rectNickName.origin.x = CGRectGetMinX(rectTimeStamp) - kContentInfoMarginLeftRight - sizeNickName.width;
    }
}

//文本条计算
- (void)caculateTextRect {
    YAMessageStyle style = _chatMessage.messageStyle;
 
    YARichText *richText = [[YARichText alloc]initWithIM];
    [richText setText:_chatMessage.content];
    
    CGSize sizeRichText = [richText sizeOfRichText];

    if (style == YAMessageStyleLeft)
    {
        rectContent = CGRectMake(0, CGRectGetMaxY(rectNickName) + kContentContainerMarginTopForLeft, kContentContainerContentWidth , 0);
        
        rectContent.origin.x = CGRectGetMaxX(rectNickIcon) + kContentContainerMarginLeftRight;
        rectContent.size.width = sizeRichText.width + kContentContainerRichTextMarginLeft + kContentContainerRichTextMarginRight;
        
        rectContent.size.height =  sizeRichText.height + kContentContainerRichTextMarginTop + kContentContainerRichTextMarginBottom;
        
        rectActivityIndicator = CGRectMake(rectContent.origin.x+rectContent.size.width+kContentContainerIndicatorMarginLeft, rectContent.origin.y + (rectContent.size.height-kContentContainerIndicatorHeight)/2.0, kContentContainerIndicatorWidth, kContentContainerIndicatorHeight);
        
        rectContentText = CGRectMake(kContentContainerRichTextMarginLeft+2,
                                         kContentContainerRichTextMarginTop,
                                         rectContent.size.width - (kContentContainerRichTextMarginLeft + kContentContainerRichTextMarginRight),sizeRichText.height);
    }
    else
    {
        
        rectContent = CGRectMake(0, kContentContainerMarginTop, kContentContainerContentWidth , 0);
        
        rectContent.origin.x = CGRectGetMinX(rectNickIcon) -  sizeRichText.width - kContentContainerMarginLeftRight - kContentContainerRichTextMarginRight - kContentContainerRichTextMarginLeft;
       
        rectContent.size.width = sizeRichText.width + kContentContainerRichTextMarginLeft + kContentContainerRichTextMarginRight;
       
        rectContent.size.height = sizeRichText.height + kContentContainerRichTextMarginTop + kContentContainerRichTextMarginBottom;
        
        rectActivityIndicator = CGRectMake(rectContent.origin.x-kContentContainerIndicatorWidth-kContentContainerIndicatorMarginRight, rectContent.origin.y + (rectContent.size.height-kContentContainerIndicatorHeight)/2.0, kContentContainerIndicatorWidth, kContentContainerIndicatorHeight);
        
        rectContentText = CGRectMake(kContentContainerRichTextMarginLeft-2,
                                         kContentContainerRichTextMarginTop,
                                         rectContent.size.width - (kContentContainerRichTextMarginLeft + kContentContainerRichTextMarginRight),sizeRichText.height);
        self.rectSendError = CGRectMake(rectActivityIndicator.origin.x-35, rectActivityIndicator.origin.y -5, 90, 30);
    }
    
//    rectContentRichText = CGRectMake(kContentContainerRichTextMarginLeft,
//                                     kContentContainerRichTextMarginTop,
//                                     rectContent.size.width - (kContentContainerRichTextMarginLeft + kContentContainerRichTextMarginRight),sizeRichText.height);
}

//语音条计算
- (void)caculateVoiceRect {
    
    rectContentText = CGRectZero;
    
    YAMessageStyle style = _chatMessage.messageStyle;
    
    CGFloat voiceRectWidth = kContentContainerContentWidth - 100;//语音条长度
    
    rectContent = CGRectMake(0, CGRectGetMaxY(rectNickName) + kContentContainerMarginTop, voiceRectWidth, 0);
    //rectContent = CGRectMake(0, kContentContainerMarginTop+ kContentContainerVoiceMarginTop, kContentContainerContentWidth - 100 , 0);
    
    if (style == YAMessageStyleLeft)
    {
        rectContent.origin.x = CGRectGetMaxX(rectNickIcon) + kContentContainerMarginLeftRight;
        rectContent.size.height =  kContentContainerVoiceHeight + kContentContainerVoiceMarginTop + kContentContainerVoiceMarginBottom;
        
        if (_chatMessage.content.length != 0)
        {
            CGFloat old_rectContentHeight = rectContent.size.height;
            
            YARichText *richText = [[YARichText alloc]initWithIM];
            richText.textWidth -= 30;//语音时间图标
            [richText setText:_chatMessage.content];
            
            CGSize sizeRichText = [richText sizeOfRichText];
            
            CGFloat textWidth = sizeRichText.width + kContentContainerRichTextMarginLeft + kContentContainerRichTextMarginRight + kContentContainerMarginLeftRight + 10;
            
            voiceRectWidth = voiceRectWidth > textWidth ? voiceRectWidth : textWidth;
            rectContent.size.width = voiceRectWidth;
            
            rectContent.size.height += sizeRichText.height;
            
            rectContentText = CGRectMake(kContentContainerRichTextMarginLeft,
                                         old_rectContentHeight - kContentContainerVoiceMarginBottom,
                                         sizeRichText.width,sizeRichText.height);
        }
        

        
    }
    else
    {
        rectContent.origin.x = CGRectGetMinX(rectNickIcon) - kContentContainerMarginLeftRight - voiceRectWidth;
        rectContent.size.height = kContentContainerVoiceHeight + kContentContainerVoiceMarginTop + kContentContainerVoiceMarginBottom;
        
        
        
        if (_chatMessage.content.length != 0) {
            
            CGFloat old_rectContentHeight = rectContent.size.height;
            
            YARichText *richText = [[YARichText alloc]initWithIM];
            richText.textWidth -= 30;//语音时间图标
            [richText setText:_chatMessage.content];

            CGSize sizeRichText = [richText sizeOfRichText];
            
            
            CGFloat textWidth = sizeRichText.width + kContentContainerRichTextMarginLeft + kContentContainerRichTextMarginRight + kContentContainerMarginLeftRight;
            
            voiceRectWidth = voiceRectWidth > textWidth ? voiceRectWidth : textWidth;
            rectContent.size.width = voiceRectWidth;
            

            rectContent.origin.x = CGRectGetMinX(rectNickIcon) - kContentContainerMarginLeftRight - voiceRectWidth;
            
            rectContent.size.height += sizeRichText.height;
            
            rectContentText = CGRectMake(0,
                                         old_rectContentHeight - kContentContainerVoiceMarginBottom,
                                         sizeRichText.width,sizeRichText.height);
            
        }
        
        rectActivityIndicator = CGRectMake(rectContent.origin.x-kContentContainerIndicatorWidth-kContentContainerIndicatorMarginRight - 35, rectContent.origin.y + (rectContent.size.height-kContentContainerIndicatorHeight)/2.0, kContentContainerIndicatorWidth, kContentContainerIndicatorHeight);
        
        self.rectSendError = CGRectMake(rectActivityIndicator.origin.x-20, rectActivityIndicator.origin.y -5, 90, 30);
        
        
    }
    
    self.rectDownloadProgress = CGRectMake(rectContent.size.width/2 - kContentContainerDownloadProgressWidth/2,
                                           rectContent.size.height/2 - kContentContainerDownloadProgressHeight/2,
                                           kContentContainerDownloadProgressWidth,kContentContainerDownloadProgressHeight);
    
    
}





- (void)setChatMessage:(YAChatMessage *)chatMessage {
    
    _chatMessage = chatMessage;
    
    [self cleanupRect];
    
    // Set nick icon frame
    [self caculateNickIconRect];
    // Set nickname , nickstamp frame
    [self caculateNickNameTimeStampRect];
    
    if (_chatMessage.mode == YAContentModeCommonText)
    {
        [self caculateTextRect];
    }
    else if(_chatMessage.mode == YAContentModeVoice)
    {
        [self caculateVoiceRect];
    }
    
    
    height = CGRectGetMaxY(rectNickIcon) > CGRectGetMaxY(rectContent) ?  CGRectGetMaxY(rectNickIcon) :  CGRectGetMaxY(rectContent);
    
    //YvDebugLog(@"[nick icon frame] %@ \n",NSStringFromCGRect(rectNickIcon));
    //YvDebugLog(@"[nick name frame] %@ \n",NSStringFromCGRect(rectNickName));
    //YvDebugLog(@"[time stamp frame] %@ \n",NSStringFromCGRect(rectTimeStamp));
    //YvDebugLog(@"[content frame] %@ \n",NSStringFromCGRect(rectContent));
    //YvDebugLog(@"[content richtext frame] %@ \n",NSStringFromCGRect(rectContentRichText));
    
}

//清空
-(void)cleanupRect
{
    self.rectNickIcon = CGRectZero;
    self.rectNickName = CGRectZero;
    self.rectTimeStamp = CGRectZero;
    self.rectContent = CGRectZero;
    self.rectContentText = CGRectZero;
    self.rectActivityIndicator = CGRectZero;
    self.rectSendError = CGRectZero;
    self.rectDownloadProgress = CGRectZero;
}


//add by bingjunXu 2015.01.22
- (CGFloat)getFrameHeight
{
    return CGRectGetMaxY(rectNickIcon) > CGRectGetMaxY(rectContent) ?  CGRectGetMaxY(rectNickIcon) :  CGRectGetMaxY(rectContent);
}


- (void)updateRect
{
    if (_chatMessage.mode == YAContentModeCommonText)
    {
        [self caculateTextRect];
    }
    else if(_chatMessage.mode == YAContentModeVoice)
    {
        [self caculateVoiceRect];
    }
    
    height = CGRectGetMaxY(rectNickIcon) > CGRectGetMaxY(rectContent) ?  CGRectGetMaxY(rectNickIcon) :  CGRectGetMaxY(rectContent);
}


@end
