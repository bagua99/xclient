//
//  YAChatMessageFrame.h
//  ChattingRoom
//
//  Created by wind on 5/8/14.
//  Copyright (c) 2014 wind. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "YAChatMessage.h"
#import "YvChatEnum.h"


// 头像高和宽
#define kContentNickIconWH         40

// 内容字体
#define kContentInfoFont           [UIFont systemFontOfSize:12]

#define kContentNickIconMarginLeftRight                 10
#define kContentNickIconMarginTop                       10

#define kContentInfoMarginLeftRight                     10
#define kContentInfoMarginTop                           10

#define kContentBubbleMarginTop                         10
#define kContentbubbleMarginLeftRight                   10

#define kContentContainerContentWidth                   220
#define kContentContainerMarginLeftRight                10
#define kContentContainerMarginTop                      10
#define kContentContainerMarginTopForLeft               2

#define kContentContainerRichTextWidth                  200
#define kContentContainerRichTextMarginLeft             10
#define kContentContainerRichTextMarginRight            10
#define kContentContainerRichTextMarginTop              5  //因为绘制文字的时候默认就有上边距，所以不对称
#define kContentContainerRichTextMarginBottom           10

#define kContentContainerVoiceWidth                 120
#define kContentContainerVoiceHeight                21
#define kContentContainerVoiceMarginLeft            10
#define kContentContainerVoiceMarginRight           10
#define kContentContainerVoiceMarginTop             5
#define kContentContainerVoiceMarginBottom          5

#define kContentContainerPhotoWidth                 100
#define kContentContainerPhotoHeight                100
#define kContentContainerPhotoMarginLeft            5
#define kContentContainerPhotoMarginRight           5
#define kContentContainerPhotoMarginTop             5
#define kContentContainerPhotoMarginBottom          5

#define kContentContainerIndicatorWidth             20
#define kContentContainerIndicatorHeight            20
#define kContentContainerIndicatorMarginLeft        5
#define kContentContainerIndicatorMarginRight       5

#define kContentContainerDownloadProgressWidth             20
#define kContentContainerDownloadProgressHeight            20
#define kContentContainerDownloadProgressMarginLeft        5
#define kContentContainerIDownloadProgressMarginRight       5

//add by bingjunXu 2015.01.22 添加代理方法，在缩略图下载完毕后通知页面刷新UI，为了解决聊天中缩略图cell尺寸问题
@class YAChatMessageFrame;
@protocol YAChatMessageFrameDelegate <NSObject>

@optional
- (void)chatMessageFrame:(YAChatMessageFrame *)messageFrame downloadThumbImageFinished:(UIImage *)thumbImage;

@end

@interface YAChatMessageFrame : NSObject
@property (nonatomic,strong) YAChatMessage *chatMessage;

@property (nonatomic,assign)CGRect rectNickIcon;
@property (nonatomic,assign)CGRect rectNickName;
@property (nonatomic,assign)CGRect rectTimeStamp;
@property (nonatomic,assign)CGRect rectContent;
@property (nonatomic,assign)CGRect rectContentText;
@property (nonatomic,assign)CGRect rectActivityIndicator;//add by bingjunXu 2015.02.27 进度指示器rect
@property (nonatomic,assign)CGRect rectSendError;//发送失败提示
@property (nonatomic,assign)CGRect rectDownloadProgress;//下载进度提示


//属性
#pragma mark - 属性
@property (nonatomic,assign)BOOL showActivityIndicator;//是否显示进度指示器
@property (nonatomic,assign)BOOL isShowSendError;//是否显示 失败提示

#pragma mark 语音属性
@property (nonatomic,assign)BOOL isPlaying;//【语音文件属性】是否正在播放中
@property (nonatomic,assign)BOOL isPlayed;//【语音文件属性】该语音消息是否已播放过了
@property (nonatomic,assign)int voicePlaySequenceId;


#pragma mark - 
@property (nonatomic,assign)CGFloat height;



@property (nonatomic, weak)id<YAChatMessageFrameDelegate> delegate;
//@property (nonatomic, weak) UITableViewCell * weakCell;


- (id)initWithMesssage:(YAChatMessage *)message  delegate:(id<YAChatMessageFrameDelegate>)delegate;

- (CGFloat)getFrameHeight;//add by bingjunXu 2015.01.22

- (void)updateRect;


@end
