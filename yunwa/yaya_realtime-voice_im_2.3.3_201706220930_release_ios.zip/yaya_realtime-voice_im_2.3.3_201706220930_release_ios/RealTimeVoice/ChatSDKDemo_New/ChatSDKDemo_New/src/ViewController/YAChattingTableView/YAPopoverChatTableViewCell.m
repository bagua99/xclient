//
//  YAPopoverChatTableViewCell.m
//  ChattingRoom
//
//  Created by wind on 5/4/14.
//  Copyright (c) 2014 wind. All rights reserved.
//

#import "YAPopoverChatTableViewCell.h"
//#import "YAPopoverChatTableViewCellBubbleView.h"
#import "UIButton+OnlineImage.h"


// 内容字体
#define kContentInfoFont           [UIFont systemFontOfSize:12]


@implementation YAPopoverChatTableViewCell {
    
 
}

@synthesize messageFrame = _messageFrame;
@synthesize nickIconImageView,nickNameLabel,content,timeStampLabel;
@synthesize delegate;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
		self.textLabel.hidden = YES;
		 
        nickIconImageView = [UIButton buttonWithType:UIButtonTypeCustom];
        nickIconImageView.layer.cornerRadius = 20.0;
        nickIconImageView.clipsToBounds = TRUE;
        
        nickNameLabel = [[UILabel alloc]initWithFrame:CGRectZero];
        timeStampLabel = [[UILabel alloc]initWithFrame:CGRectZero];
        content = [UIButton buttonWithType:UIButtonTypeCustom];
        self.sendErrorPrompt = [[UILabel alloc]initWithFrame:CGRectZero];
        self.sendErrorPrompt.textColor = [UIColor redColor];
        self.sendErrorPrompt.font = [UIFont systemFontOfSize:12];
        
        [nickIconImageView addTarget:self action:@selector(nickIconClick:) forControlEvents:UIControlEventTouchUpInside];
        [content addTarget:self action:@selector(contentClick:) forControlEvents:UIControlEventTouchUpInside];
        
        //content.layer.masksToBounds = YES;
        //content.layer.cornerRadius = 10;
        
       // richText = [[YARichText alloc]init];
        
        [self addSubview:nickNameLabel];
        [self addSubview:nickIconImageView];
        [self addSubview:timeStampLabel];
        [self addSubview:content];
        [self addSubview:self.sendErrorPrompt];
       // [content addSubview:richText];
        
        [self setBackgroundColor:[UIColor whiteColor]];
        
        [nickNameLabel setFont:kContentInfoFont];
        [timeStampLabel setFont:kContentInfoFont];
        
        _activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        [self addSubview:_activityIndicator];
        
        
    }
    return self;
}

- (void)setMessageFrame:(YAChatMessageFrame *)messageFrame
{
    _messageFrame = messageFrame;
    //_messageFrame.weakCell = self;

    //[nickIconImageView ]
    [nickIconImageView setOnlineImage:messageFrame.chatMessage.iconUrl placeholderImage:[UIImage imageNamed:@"icon_headIcon_placeholder.png"]];
    [nickIconImageView setFrame:messageFrame.rectNickIcon];
    

    
//    [timeStampLabel setText:messageFrame.chatMessage.timeinterval];
    [timeStampLabel setFrame:messageFrame.rectTimeStamp];
    
    [content setFrame:messageFrame.rectContent];
    
    _activityIndicator.frame = messageFrame.rectActivityIndicator;
    if(messageFrame.showActivityIndicator)
    {
        _activityIndicator.hidden = NO;
        [_activityIndicator startAnimating];
    }
    else
    {
        _activityIndicator.hidden = YES;
        [_activityIndicator stopAnimating];
    }
    
    //self.sendErrorPrompt.text = @"(发送失败)";
    if (messageFrame.isShowSendError) {
        
        [self showSendErrorPrompt:YES];
    }
    else
    {
        
        [self showSendErrorPrompt:NO];
    }
  
    UIImage *normal ;
    if (messageFrame.chatMessage.messageStyle == YAMessageStyleLeft) {
    
//        normal=[[UIImage imageNamed:@"chat_message_left_bg.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(14, 10, 4, 5)];
        normal = [UIImage imageNamed:@"chat_message_left_bg.png"];
        normal = [normal stretchableImageWithLeftCapWidth:normal.size.width * 0.5 topCapHeight:normal.size.height * 0.7];
        
        
        [nickNameLabel setText:messageFrame.chatMessage.nickName];
        [nickNameLabel setFrame:messageFrame.rectNickName];
    }
    else{
    
        normal = [UIImage imageNamed:@"chat_message_right_bg.png"];
        normal = [normal stretchableImageWithLeftCapWidth:normal.size.width * 0.5 topCapHeight:normal.size.height * 0.7];
        
        [nickNameLabel setText:@""];
        [nickNameLabel setFrame:messageFrame.rectNickName];
    }
    
    [content setBackgroundImage:normal forState:UIControlStateNormal];
    
//    [richText setText:messageFrame.chatMessage.content];
//    [richText setFrame:messageFrame.rectContentRichText];

}

- (void)awakeFromNib
{
    // Initialization code
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)nickIconClick:(id)sender {
    if (delegate
        && [delegate respondsToSelector:@selector(nickIconClick:)]) {
        [delegate nickIconImageDidSelected:self];
    }
}

- (IBAction)contentClick:(id)sender {
    if (delegate
        && [delegate respondsToSelector:@selector(contentDidSelected:)]) {
        [delegate contentDidSelected:self];
    }
}

//- (void)updateInterface
//{
//    if(_messageFrame.showActivityIndicator)
//    {
//        _activityIndicator.hidden = NO;
//        [_activityIndicator startAnimating];
//    }
//    else
//    {
//        _activityIndicator.hidden = YES;
//        [_activityIndicator stopAnimating];
//    }
//}

-(void)showActivityIndicator:(BOOL)isShowActivityIndicator
{
    if (isShowActivityIndicator) {
        _activityIndicator.hidden = NO;
        [_activityIndicator startAnimating];
    }
    else
    {
        _activityIndicator.hidden = YES;
        [_activityIndicator stopAnimating];
    }
}

-(void)showSendErrorPrompt:(BOOL)isShow
{
    if (isShow) {
        self.sendErrorPrompt.text = @"(发送失败)";
        self.sendErrorPrompt.frame = _messageFrame.rectSendError;
    }
    else
    {
        self.sendErrorPrompt.text = @"";
        self.sendErrorPrompt.frame = CGRectZero;
    }
}

@end
