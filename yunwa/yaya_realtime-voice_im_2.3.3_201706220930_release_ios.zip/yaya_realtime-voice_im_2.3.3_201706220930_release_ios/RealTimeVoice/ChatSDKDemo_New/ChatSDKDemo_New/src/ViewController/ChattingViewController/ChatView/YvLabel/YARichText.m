//
//  YARichText.m
//  ChattingRoom
//
//  Created by wind on 5/5/14.
//  Copyright (c) 2014 wind. All rights reserved.
//

#import "YARichText.h"
#import <CoreText/CoreText.h>
#import "YARegularExpression.h"
#import "NSArray+Yv.h"
#import "NSString+Yv.h"
#import "Yunva_TBXML.h"
//#import "TBXML.h"

#define AttributedImageNameKey      @"ImageName"

// 空格
#define PlaceHolder     @" "

// 正则表达式匹配
#define EmotionItemPattern          @"\\[[\\u4e00-\\u9fa5\\w]{1,2}\\]"

// 内容字体
#define kContentFontSize            14

// 内容宽度
#define kContentTextWidth           ([UIScreen mainScreen].bounds.size.width-120)//200

// 表情宽度 Equal to font size
#define kContentEmojWidth       20

// 表情高度 Equal to font size
#define kContentEmojHeight      20

// 表情绘制Padding top 调整
#define kContentEmojPaddingTop   5

#define kContentLinePadding   2


@interface WayaEmojEntity : NSObject
@property (nonatomic,strong)NSString *key;
@property (nonatomic,assign)NSRange  range;

- (id)initWithkey:(NSString *)key range:(NSRange)range;
@end

@implementation WayaEmojEntity

- (id)initWithkey:(NSString *)key range:(NSRange)range {
    if (self = [super init]) {
        self.key = key;
        self.range = range;
    }
    return self;
}

@end

@interface YARichText ()
@property (nonatomic,assign)BOOL onlyOneLine;
@end

@implementation YARichText {
    //NSMutableDictionary  *emojDict;
    NSMutableAttributedString  *attributedString;
    CTTypesetterRef typesetter;
    NSUInteger  emojsCount;
    
    //IMChatType imChatType;
    NSString *_originText;
}
@synthesize text = _text,textFontSize,textWidth;


- (void)setText:(NSString *)text
{
    _originText = text;
    _text = text;
    [self buildAttributes];
    
    [self setNeedsLayout];
    [self setNeedsDisplay];
}


- (id)initWithIM{
    if (self = [super init]) {
        
        [self attachLongPressHandler];
        
        /*
        emojDict = [[NSMutableDictionary alloc] init];
        Yunva_TBXML* tbxml = [[Yunva_TBXML alloc] initWithXMLFile:@"live_sdk_emoji.xml" error:nil];
        TBXMLElement * root = tbxml.rootXMLElement;
        
        // if root element is valid
        if (root) {
            TBXMLElement * noteElement = [Yunva_TBXML childElementNamed:@"item" parentElement:root];
            while (noteElement != nil) {
                [emojDict setObject:[Yunva_TBXML valueOfAttributeNamed:@"value" forElement:noteElement] forKey:[Yunva_TBXML valueOfAttributeNamed:@"key" forElement:noteElement]];
                noteElement = [Yunva_TBXML nextSiblingNamed:@"item" searchFromElement:noteElement];
            }
        }
        */
        
        textFontSize = kContentFontSize;
        textWidth = kContentTextWidth;
        _text = @"";
        
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
}


- (void)buildAttributes {
    
    // Set CTRunDelegateCallbacks for emotions
    
    // ... 查找表情的index位置
    NSMutableArray *__emojsIndex = [[NSMutableArray alloc]init];
    
    // ... 查找表情对应的字符串
    NSMutableArray *__emojsKey = [[NSMutableArray alloc]init];
/*
    if (imChatType == IMChatTypeWaya) {
        
        NSMutableArray * wayaEmojEntitys= [[NSMutableArray alloc] init];
        
        [emojDict enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
            
            NSArray * rangearray = [YARegularExpression itemIndexesWithPattern:key inString:_text];
            for (int i=0;i<rangearray.count; i++) {
                NSValue *nsv = [rangearray objectAtIndex:i];
                WayaEmojEntity * entity = [[WayaEmojEntity alloc] initWithkey:key range:nsv.rangeValue];
                [wayaEmojEntitys addObject:entity];
            }
        }];
        
        //        [emojDict enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        //            NSRange foundObj=[_text rangeOfString:(NSString *)key options:NSCaseInsensitiveSearch];
        //            if (foundObj.length >0) {
        //                WayaEmojEntity * entity = [[WayaEmojEntity alloc] initWithkey:key range:foundObj];
        //                [wayaEmojEntitys addObject:entity];
        //            }
        //        }];
        
        
        wayaEmojEntitys = [[NSMutableArray alloc] initWithArray:[wayaEmojEntitys sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
            WayaEmojEntity * entity1,*entity2;
            entity1 =(WayaEmojEntity *)obj1;
            entity2 =(WayaEmojEntity *)obj2;
            if (entity1.range.location < entity2.range.location) {
                return NSOrderedAscending;
            }
            return NSOrderedDescending;
        }]];
        
        for (WayaEmojEntity * entity in wayaEmojEntitys) {
            [__emojsIndex addObject:[NSValue valueWithRange:entity.range]];
            [__emojsKey addObject:entity.key];
        }
    }
    else
    {
        [__emojsIndex addObjectsFromArray:[YARegularExpression itemIndexesWithPattern:EmotionItemPattern inString:_text]];
        [__emojsKey addObjectsFromArray:[YARegularExpression itemStringsWithPattern:EmotionItemPattern inString:_text]];
    }

    
    // ... 过滤不存在的表情，ps:上面查找可能找到人为输入的 ［表情］但又没有表情支持，删除之，当作文字发送
    NSMutableIndexSet *nonExistIds = [[NSMutableIndexSet alloc]init];
    
    NSInteger i = 0;
    for (NSString *__emoj in __emojsKey) {
        if ([emojDict objectForKey:__emoj] == NULL) {
            [nonExistIds addIndex:i];
        }
        i++;
    }
    
    [__emojsIndex removeObjectsAtIndexes:nonExistIds];
    [__emojsKey removeObjectsAtIndexes:nonExistIds];
    
    emojsCount = __emojsIndex.count;
    
    // ... 替换表情字符串为空格
    _text = [_text replaceCharactersAtIndexes:__emojsIndex withString:PlaceHolder];
    
    //YvDebugLog(@"[Format content] %@",_text);
    
    // ... 新的表情的占位符的range数组
    NSArray *newRange = [__emojsIndex offsetRangesInArrayBy:PlaceHolder.length];
*/
    
    // ... 根据range数组添加attribute
    
    CTFontRef font = CTFontCreateUIFontForLanguage(kCTFontSystemFontType,textFontSize,0);
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                       (__bridge_transfer id)font, (id)kCTFontAttributeName,nil];
    //add by huangzhijun 2014.9.23
    if (self.textColor)
    {
        [attributes setObject:self.textColor forKey:NSForegroundColorAttributeName];
    }//end by huangzhijun 2014.9.23
    
    attributedString = [[NSMutableAttributedString alloc] initWithString:_text attributes:attributes];
    
/*
    for(NSInteger i = 0; i < [newRange count]; i++)
    {
        NSRange range = [[newRange objectAtIndex:i] rangeValue];
        NSString *emotionName = [__emojsKey objectAtIndex:i];
        
        [attributedString addAttribute:AttributedImageNameKey value:[emojDict objectForKey:emotionName] range:range];
        [attributedString addAttribute:(NSString *)kCTRunDelegateAttributeName value:(__bridge_transfer id)newEmotionRunDelegate() range:range];
    }
*/
}



- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


- (void)layoutSubviews {
    
    CGSize size = [self sizeOfRichText];
    [self setFrame:CGRectMake(self.frame.origin.x, self.frame.origin.y, textWidth,size.height)];
}

- (CGSize)sizeOfRichText {
    
    CFIndex start = 0;
    NSInteger length = [attributedString length];
    CGFloat height = 3; // Add inset
    CGFloat width = 0;
    
    if (typesetter == nil)
    {
        typesetter =  CTTypesetterCreateWithAttributedString((__bridge CFAttributedStringRef)(attributedString));
    }
    
    CFIndex count = CTTypesetterSuggestClusterBreak(typesetter, start, textWidth);
    
    // If only one line
    if (self.onlyOneLine)
    {
        NSInteger ejCount = emojsCount;
        NSInteger tempEmojsCount = ejCount-1 >= 0 ? emojsCount-1 : 0;
        width = [attributedString.string sizeWithFont:[UIFont systemFontOfSize:textFontSize]].width - [PlaceHolder sizeWithFont:[UIFont systemFontOfSize:textFontSize]].width * tempEmojsCount + emojsCount * kContentEmojWidth;
        height += kContentEmojHeight+kContentLinePadding;
    }
    else
    {
        if (length <= count)
        {
            NSInteger ejCount = emojsCount;
            NSInteger tempEmojsCount = ejCount-1 >= 0 ? emojsCount-1 : 0;
            width = [attributedString.string sizeWithFont:[UIFont systemFontOfSize:textFontSize]].width - [PlaceHolder sizeWithFont:[UIFont systemFontOfSize:textFontSize]].width * tempEmojsCount + emojsCount * kContentEmojWidth;
            height += kContentEmojHeight+kContentLinePadding;
        }
        else { // If multiline
            while (start < length)
            {
                CFIndex count = CTTypesetterSuggestClusterBreak(typesetter, start, textWidth);
                start += count;
                height += kContentEmojHeight+kContentLinePadding;
            }
            
            width = textWidth;
        }
    }
    CFRelease(typesetter);
    typesetter = nil;
    
    return CGSizeMake(width, height);
}

CTRunDelegateRef newEmotionRunDelegate()
{
    
    // Here must assign a new address
    NSString *emotionRunName = [NSString stringWithFormat:@"com.Yunva.yaya.emotionRunName []"];
    
    CTRunDelegateCallbacks imageCallbacks;
    imageCallbacks.version = kCTRunDelegateVersion1;
    imageCallbacks.dealloc = RunDelegateDeallocCallback;
    imageCallbacks.getAscent = RunDelegateGetAscentCallback;
    imageCallbacks.getDescent = RunDelegateGetDescentCallback;
    imageCallbacks.getWidth = RunDelegateGetWidthCallback;
    CTRunDelegateRef runDelegate = CTRunDelegateCreate(&imageCallbacks,
                                                       (void *)(emotionRunName));
    
    return runDelegate;
}

void RunDelegateDeallocCallback( void* refCon ){
    
}

CGFloat RunDelegateGetAscentCallback( void *refCon ){
    //YvDebugLog(@"[Get Ascent]%d",kContentEmojHeight);
    return kContentEmojHeight;
}

CGFloat RunDelegateGetDescentCallback(void *refCon){
    return 0;
}

CGFloat RunDelegateGetWidthCallback(void *refCon){
    //YvDebugLog(@"[Get Width]%d",kContentEmojWidth);
    return kContentEmojWidth ;
}


static inline CGPoint Emoji_Origin_For_Line(CTLineRef line, CGPoint lineOrigin, CTRunRef run) {
    CGFloat x = lineOrigin.x + CTLineGetOffsetForStringIndex(line, CTRunGetStringRange(run).location, NULL) ;
    CGFloat y = lineOrigin.y - kContentEmojPaddingTop;
    return CGPointMake(x, y);
}


void Draw_Emoji_For_Line(CGContextRef context, CTLineRef line, id owner, CGPoint lineOrigin)
{
    CFArrayRef runs = CTLineGetGlyphRuns(line);
    NSUInteger count = CFArrayGetCount(runs);
    
    for(NSInteger i = 0; i < count; i++)
    {
        CTRunRef aRun = CFArrayGetValueAtIndex(runs, i);
        CFDictionaryRef attributes = CTRunGetAttributes(aRun);
        NSString *emojiName = (NSString *)CFDictionaryGetValue(attributes,AttributedImageNameKey);
        if (emojiName) {
            UIImage *image = [UIImage imageNamed:emojiName];
            if (image) {
                CGRect imageDrawRect;
                imageDrawRect.size = CGSizeMake(kContentEmojWidth, kContentEmojHeight);
                imageDrawRect.origin = Emoji_Origin_For_Line(line, lineOrigin, aRun);
                CGContextDrawImage(context, imageDrawRect, image.CGImage);
            }
        }
    }
}


- (void)drawRect:(CGRect)rect {
    
    if (typesetter == nil) {
        typesetter =  CTTypesetterCreateWithAttributedString((__bridge CFAttributedStringRef)
                                                             (attributedString));
    }
    
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSaveGState(context);
    //设置颜色的方法
    //    CGContextSetFillColor(context, CGColorGetComponents([UIColor redColor].CGColor));
    
    CGContextTranslateCTM(context, 0, self.bounds.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    
    
    CGFloat y = self.bounds.size.height - kContentEmojHeight;
    CFIndex start = 0;
    NSInteger length = [attributedString length];
    
    
    //从下往上绘制的
    while (start < length)
    {
        //建议的一行字符数
        CFIndex count = CTTypesetterSuggestClusterBreak(typesetter, start, textWidth);
        CTLineRef line = CTTypesetterCreateLine(typesetter, CFRangeMake(start, count));
        CGContextSetTextPosition(context, 0, y);
        
        CTLineDraw(line, context);
        Draw_Emoji_For_Line(context, line, self, CGPointMake(0, y));
        
        start += count;
        y  -=   kContentEmojHeight+kContentLinePadding;
        
        CFRelease(line);
    }
    
    CGContextRestoreGState(context);
    
    CFRelease(typesetter);
    typesetter = nil;
}

#pragma mark - 复制粘贴相关
- (BOOL)canBecomeFirstResponder
{
    return YES;
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    return (action == @selector(copy:));
}

- (void)copy:(id)sender
{
    UIPasteboard *pboard = [UIPasteboard generalPasteboard];
    pboard.string = _originText;
}

- (void)attachLongPressHandler
{
    self.userInteractionEnabled = YES;  //用户交互的总开关
//    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
//    [self addGestureRecognizer:longPress];

}

-(void)handleLongPress:(UIGestureRecognizer *)recognizer
{
    [self becomeFirstResponder];
    //UIMenuItem *menuItem = [[UIMenuItem alloc] initWithTitle:@"复制" action:@selector(copy:)];
    //[[UIMenuController sharedMenuController] setMenuItems:[NSArray arrayWithObjects:menuItem, nil]];
    [[UIMenuController sharedMenuController] setTargetRect:[self superview].bounds inView:[self superview]];
    [[UIMenuController sharedMenuController] setMenuVisible:YES animated: YES];
}

@end
