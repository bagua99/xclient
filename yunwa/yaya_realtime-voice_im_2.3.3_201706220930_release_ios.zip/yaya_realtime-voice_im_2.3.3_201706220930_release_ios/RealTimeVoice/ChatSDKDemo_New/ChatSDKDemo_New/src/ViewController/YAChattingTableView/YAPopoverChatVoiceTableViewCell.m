//
//  YAPopoverChatVoiceTableViewCell.m
//  ChattingRoom
//
//  Created by 朱文腾 on 5/27/14.
//  Copyright (c) 2014 wind. All rights reserved.
//

#import "YAPopoverChatVoiceTableViewCell.h"
#import "UCZProgressView.h"
#import "YvSkin.h"

@implementation YAPopoverChatVoiceTableViewCell
@synthesize voiceImageView,voiceTimeLabel;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.voicePlaySequenceId = -1;
    }
    return self;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
    
        voiceImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"chattingvoice.png"]];
        voiceTimeLabel = [[UILabel alloc]initWithFrame:CGRectZero];
        [voiceTimeLabel setText:@"0'"];
        [voiceTimeLabel setTextAlignment:NSTextAlignmentCenter];
        voiceTimeLabel.font = [UIFont systemFontOfSize:12];
        [self.content addSubview:voiceImageView];
        [self addSubview:voiceTimeLabel];
        
        
         }
    return self;
}

- (void)setMessageFrame:(YAChatMessageFrame *)messageFrame {
    [super setMessageFrame:messageFrame];
    
    if (self.messageFrame.chatMessage.messageStyle == YAMessageStyleLeft) {
        //[voiceImageView setImage:[UIImage imageNamed:@"chatting_voice_left.png"]];
        [voiceImageView setImage:[UIImage imageNamed:@"voice_play_left1.png"]];
        [voiceImageView setFrame:CGRectMake(kContentContainerVoiceMarginLeft, kContentContainerVoiceMarginTop, 13, 18)];
        
        
        voiceImageView.animationImages = [[NSArray alloc]initWithObjects:[UIImage imageNamed:@"voice_play_left1.png"],[UIImage imageNamed:@"voice_play_left2.png"],[UIImage imageNamed:@"voice_play_left3.png"],[UIImage imageNamed:@"voice_play_left4.png"], nil];
        voiceImageView.animationRepeatCount = 0;
        voiceImageView.animationDuration = 1;
        
        
        
        [voiceTimeLabel setFrame:CGRectMake(CGRectGetMaxX(self.content.frame) + 5, CGRectGetMinY(self.content.frame)+ kContentContainerVoiceMarginTop, 35, 21)];
        
        
        
    }
    else if(self.messageFrame.chatMessage.messageStyle == YAMessageStyleRight) {
        //[voiceImageView setImage:[UIImage imageNamed:@"chatting_voice_right.png"]];
        [voiceImageView setImage:[UIImage imageNamed:@"voice_play_right1.png"]];
        [voiceImageView setFrame:CGRectMake(CGRectGetWidth(self.content.frame) - kContentContainerVoiceMarginRight - 13, 5, 13, 18)];
        
        voiceImageView.animationImages = [[NSArray alloc]initWithObjects:[UIImage imageNamed:@"voice_play_right1.png"],[UIImage imageNamed:@"voice_play_right2.png"],[UIImage imageNamed:@"voice_play_right3.png"],[UIImage imageNamed:@"voice_play_right4.png"], nil];
        voiceImageView.animationRepeatCount = 0;
        voiceImageView.animationDuration = 1;
        
        
        [voiceTimeLabel setFrame:CGRectMake(CGRectGetMinX(self.content.frame) - 35, CGRectGetMinY(self.content.frame) + kContentContainerVoiceMarginTop, 35, 21)];
        
    }
    
    // 设置时间
    NSString * voiceTimeSec = ((YAChatMessageVoice *)messageFrame.chatMessage).voiceTimeSec;
    [voiceTimeLabel setText:voiceTimeSec];
    voiceTimeLabel.textColor = FontColorForGray;
    //voiceTimeLabel.backgroundColor = [UIColor orangeColor];
    
    [self _setText:self.messageFrame.chatMessage.content textRect:self.messageFrame.rectContentText MessageStyle:self.messageFrame.chatMessage.messageStyle];
    
   
    if ( messageFrame.isPlaying) {
        
        [self voicePlayStart];
    }
    else
    {
        [self voicePlayStop];
        
        if (self.voiceDownloadProgressView) {
            [self hideVoiceDownloadProgress];
        }
    }
    
    //NSLog(@"voiceTimeSec = %@",voiceTimeSec);
}


-(void)_setText:(NSString *)text textRect:(CGRect)textRect MessageStyle:(YAMessageStyle)messageStyle
{
    if (!text || text.length == 0) {
        
        [richText setText:@""];
        [richText setFrame:CGRectZero];
        return;
    }
    
    if (richText == nil) {
        richText = [[YARichText alloc]initWithIM];
        [self.content addSubview:richText];
    }
    //add by huangzhijun 2014.9.23 设置颜色一定要前于设置setText;
    if (YAMessageStyleRight == messageStyle) {
        richText.textColor = [UIColor whiteColor];
        
    }else if(YAMessageStyleLeft == messageStyle)
    {
        richText.textColor = [UIColor blackColor];
    }//end by huangzhijun 2014.9.23
    
    [richText setText:text];
    [richText setFrame:textRect];
    //richText.backgroundColor = [UIColor lightGrayColor];
    
    
    [richText addTarget:self action:@selector(contentClick:) forControlEvents:UIControlEventTouchUpInside];// 调用基类的 内部函数 - (IBAction)contentClick:(id)sender
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/


-(void)voicePlayStart
{
    self.messageFrame.isPlaying = YES;
    self.messageFrame.isPlayed = YES;
    [voiceImageView startAnimating];
}


-(void)voicePlayStop
{
    self.messageFrame.isPlaying = NO;
    [voiceImageView stopAnimating];
}


#pragma mark - 播放id
-(int)voicePlaySequenceId
{
    return self.messageFrame.voicePlaySequenceId;
}

-(void)setVoicePlaySequenceId:(int)voicePlaySequenceId
{
    self.messageFrame.voicePlaySequenceId = voicePlaySequenceId;
}

#pragma mark - 
-(void)showVoiceDownloadProgress
{
    if (!self.voiceDownloadProgressView) {
        
        self.voiceDownloadProgressView = [[UCZProgressView alloc] initWithFrame:self.messageFrame.rectDownloadProgress];
        self.voiceDownloadProgressView.tintColor = [UIColor purpleColor];
        self.voiceDownloadProgressView.textColor = [UIColor purpleColor];
        self.voiceDownloadProgressView.showsText = YES;
        [self.content addSubview:self.voiceDownloadProgressView];
        
        
    }
    else
    {
        self.voiceDownloadProgressView.frame = self.messageFrame.rectDownloadProgress;
    }

}

-(void)setVoiceDownloadProgress:(float)progress
{
    self.voiceDownloadProgressView.progress = progress;
}

-(void)hideVoiceDownloadProgress
{
    self.voiceDownloadProgressView.frame = CGRectZero;
    self.voiceDownloadProgressView.indeterminate = NO;
    self.voiceDownloadProgressView.progress = 1.0;
    [self.voiceDownloadProgressView removeFromSuperview];
    self.voiceDownloadProgressView = nil;
}

@end
