//
//  YAChatMessage.h
//  ChattingRoom
//
//  Created by wind on 5/4/14.
//  Copyright (c) 2014 wind. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef enum {
	YAMessageStyleLeft = 0,
	YAMessageStyleRight = 1
} YAMessageStyle;

typedef enum {
    YAContentModeCommonText = 0,    // 普通文本
    YAContentModeVoice = 1, // 语音

} YAContentMode;


@interface YAChatMessage : NSObject

@property (nonatomic,strong) NSString *iconUrl;                          // 头像
@property (nonatomic,strong) NSString *nickName;                         // 姓名
@property (nonatomic,strong) NSDate * time;                          // 时间轴
@property (nonatomic,strong) NSString *content;                          // 内容   (普通文本,以及富文本)
@property (nonatomic,assign) YAMessageStyle  messageStyle;               // 样式
@property (nonatomic,assign) YAContentMode mode;                         // 内容模式

//@property (nonatomic, assign)UInt32 targetId;//目标用户id
@property (nonatomic, assign,readonly)NSInteger uniqueId;

- (id)initWithMessage:(NSString *)_icon  nickName:(NSString *)_nickName time:(NSDate *)_time content:(NSString *)_content style:(YAMessageStyle)_messageStyle withUniqueId:(NSInteger)uniqueId;


@end
