//
//  YAPopoverChatTableViewCell.h
//  ChattingRoom
//
//  Created by 朱文腾 on 5/4/14.
//  Copyright (c) 2014 wind. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YAChatMessage.h"
#import "YAChatMessageFrame.h"
#import "YAChatMessageVoice.h"



@protocol YAPopoverChatTableViewCellDelegate <NSObject>
- (void)nickIconImageDidSelected:(id)obj;
- (void)contentDidSelected:(id)obj;

@end

@interface YAPopoverChatTableViewCell : UITableViewCell
{
   //YARichText *richText;                       // 富文本

}

@property (nonatomic,strong)YAChatMessageFrame *messageFrame;
@property (nonatomic,strong)UIButton  *nickIconImageView;          // 头像
@property (nonatomic,strong)UILabel  *nickNameLabel;               // 昵称
@property (nonatomic,strong)UILabel  *timeStampLabel;              // 时间轴
@property (nonatomic,strong)UIButton   *content;                     // 内容
@property (nonatomic,strong)UIActivityIndicatorView *activityIndicator;//发送消息指示器
@property (nonatomic,strong)UILabel * sendErrorPrompt;//发送消息错误提示

@property (nonatomic,weak)id <YAPopoverChatTableViewCellDelegate> delegate;

//- (void)updateInterface;

-(void)showActivityIndicator:(BOOL)isShowActivityIndicator;

-(void)showSendErrorPrompt:(BOOL)isShow;


//内部函数
- (IBAction)contentClick:(id)sender;

@end
