//
//  YAPopoverChatVoiceTableViewCell.m
//  ChattingRoom
//
//  Created by 朱文腾 on 5/27/14.
//  Copyright (c) 2014 wind. All rights reserved.
//

#import "YAPopoverChatTextTableViewCell.h"
#import "YvChatEnum.h"

@implementation YAPopoverChatTextTableViewCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
- (void)setMessageFrame:(YAChatMessageFrame *)messageFrame  {
    [super setMessageFrame:messageFrame];
    if (richText == nil) {
        richText = [[YARichText alloc]initWithIM];
        [self.content addSubview:richText];
    }
    //add by huangzhijun 2014.9.23 设置颜色一定要前于设置setText;
    if (YAMessageStyleRight == messageFrame.chatMessage.messageStyle) {
        richText.textColor = [UIColor whiteColor];
        
    }else if(YAMessageStyleLeft == messageFrame.chatMessage.messageStyle)
    {
        richText.textColor = [UIColor blackColor];
    }//end by huangzhijun 2014.9.23
    
    [richText setText:messageFrame.chatMessage.content];
    [richText setFrame:messageFrame.rectContentText];
}

@end
