//
//  YvChatEnum.h
//  yaya
//
//  Created by 朱文腾 on 14-6-27.
//  Copyright (c) 2014年 YunVa. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum InputType_{
    InputType_Common = 0,           // 普通输入
    InputType_Facial = 1,           // 其他输入
    InputType_Voice  = 2,           // 声音输入
    InputType_Facial_Emotion = 3,   // 表情输入
    InputType_Facial_Photo = 4      // 图片输入
}InputType;

typedef enum InputVoiceType_ {
    InputVoiceType_RealTime = 0, InputVoiceType_Record = 1
}InputVoiceType;

////聊天的类别
//typedef NS_ENUM(short, IMChatType)
//{
//    IMChatTypeYaya = 0,
//    IMChatTypeWaya = 1,
//};

//typedef NS_ENUM(short, IMChatSubType)
//{
//    IMChatSubTypePrivate = 0,
//    IMChatSubTypeSecretary,
//    IMChatSubTypeTeam,
//    IMChatSubTypeGroup,
//    IMChatSubTypeCustomerService,
//};

@interface YvChatEnum : NSObject

@end
