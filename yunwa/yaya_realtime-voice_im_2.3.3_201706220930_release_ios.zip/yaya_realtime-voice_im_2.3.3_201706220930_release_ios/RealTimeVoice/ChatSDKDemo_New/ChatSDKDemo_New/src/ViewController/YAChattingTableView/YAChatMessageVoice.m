//
//  YAChatMessageVoice.m
//  yaya
//
//  Created by wind on 6/7/14.
//  Copyright (c) 2014 YunVa. All rights reserved.
//

#import "YAChatMessageVoice.h"



@implementation YAChatMessageVoice

- (id)initWithMessage:(NSString *)icon nickName:(NSString *)nickName time:(NSDate *)time voiceUrl:(NSString *)voiceUrl voiceFilePath:(NSString *)voiceFilePath voiceTime:(NSString *)voiceTime style:(YAMessageStyle)messageStyle withUniqueId:(NSInteger)uniqueId
{
    if (self = [super initWithMessage:icon nickName:nickName time:time content:@"" style:messageStyle withUniqueId:uniqueId])
    {
        _voiceUrl = voiceUrl;
        _voiceTimeSec = voiceTime;
        _voiceFilePath = voiceFilePath;
        
        self.mode = YAContentModeVoice;//语音
    }
    return self;
}

@end
