//
//  YvRealVideoController.h
//  ChatSDKDemo_New
//
//  Created by dada on 15/11/10.
//  Copyright (c) 2015年 com.yunva.yaya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YvRealVideoController : UIViewController
@property (weak, nonatomic) IBOutlet UIView *bgview;
@property (weak, nonatomic) IBOutlet UIImageView *selfView;
@property (weak, nonatomic) IBOutlet UIImageView *firstImage;
@property (weak, nonatomic) IBOutlet UIImageView *secondImage;
@property (weak, nonatomic) IBOutlet UIImageView *thirdIMage;
@property (weak, nonatomic) IBOutlet UIImageView *fourImage;


@property (weak, nonatomic) IBOutlet UILabel *firstLable;
@property (weak, nonatomic) IBOutlet UILabel *secondLabel;
@property (weak, nonatomic) IBOutlet UILabel *thridLabel;
@property (weak, nonatomic) IBOutlet UILabel *fourLabel;


@property (nonatomic, assign) NSInteger position;
@property (nonatomic, assign) NSInteger videoCount;//视频个数


//1～4ImageView宽高约束
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *first_h;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *first_w;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *second_h;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *second_w;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *third_w;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *third_h;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *four_w;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *four_h;



@end
