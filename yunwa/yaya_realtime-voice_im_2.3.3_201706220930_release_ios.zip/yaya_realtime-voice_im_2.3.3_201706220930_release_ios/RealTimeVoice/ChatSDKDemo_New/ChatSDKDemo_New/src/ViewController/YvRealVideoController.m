//
//  YvRealVideoController.m
//  ChatSDKDemo_New
//
//  Created by dada on 15/11/10.
//  Copyright (c) 2015年 com.yunva.yaya. All rights reserved.
//

#import "YvRealVideoController.h"
//#import "YvChatManage+Video.h"
#import "YvChatManage.h"
#import "Utilities.h"
#define showHUD 1
@interface YvRealVideoController ()
{
    BOOL _first ;
    BOOL _second;
    BOOL _third;
    BOOL _four;
}
@property (nonatomic, strong)UIBarButtonItem *openOrcloseRecod;
@property (nonatomic, assign)BOOL videoState;//0:open 1:close;
@end

@implementation YvRealVideoController

- (void)viewDidLoad {
    [super viewDidLoad];
    if([self respondsToSelector:@selector(edgesForExtendedLayout)])
    {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    _first = YES;
    _second = YES;
    _third = YES;
    _four = YES;
    
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(enterForGround) name:UIApplicationDidBecomeActiveNotification object:nil];
    
    //系统检测到有电话、SMS信息、或者日历警告发生
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(lockSreen:) name:@"appWillResignAcive" object:nil];
    
    //监听锁屏
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(lockSreen:) name:@"screemUnlock" object:nil];
    
    
    
    if (self.videoCount==2) {
        self.secondImage.hidden = YES;
        self.thirdIMage.hidden = YES;
        self.fourImage.hidden = YES;
        
        self.secondLabel.hidden = YES;
        self.thridLabel.hidden = YES;
        self.fourLabel.hidden = YES;
    }
    if (self.videoCount==3) {
        self.thirdIMage.hidden = YES;
        self.fourImage.hidden = YES;
        
        self.thridLabel.hidden = YES;
        self.fourLabel.hidden = YES;
    }
    if (self.videoCount==4) {
        self.fourImage.hidden = YES;
        
        self.fourLabel.hidden = YES;
    }

    
    self.videoState = 0;

    //用户接受服务器实时视频通知的回调
//    [YvChatManage sharedInstance].videoDelegate= self;
    
    //开始播放视频(初始化视频解码器) 传入UIview即可
//    [[YvChatManage sharedInstance] showVideoInView:@[self.firstImage,self.secondImage,self.thirdIMage,self.fourImage]];


    //切换摄像头
    UIBarButtonItem *switchCamera=[[UIBarButtonItem alloc]initWithTitle:@"切换" style:UIBarButtonItemStylePlain target:self action:@selector(switchForCamera)];
    _openOrcloseRecod=[[UIBarButtonItem alloc]initWithTitle:@"打开视频" style:UIBarButtonItemStylePlain target:self action:@selector(openOrcloseVideo)];
    self.navigationItem.rightBarButtonItems=@[switchCamera,_openOrcloseRecod];
    
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [[YvChatManage sharedInstance]chatVideo_ConnectToNetHost];
//
//    });
}
-(void)lockSreen:(NSNotification*)nofi
{
    NSDictionary *num = (NSDictionary*)nofi.userInfo;
    if ([num[@"a"] isEqualToNumber:@(1)]) {
        [[UIApplication sharedApplication]beginBackgroundTaskWithExpirationHandler:^{
            if ([_openOrcloseRecod.title isEqualToString:@"关闭视频"]) {
                [self openOrcloseVideo];
            }
        }];
        
//        [Utilities showTextHUD:@"失活通知" andView:self.view maintainTime:5];
        return;
    }else
    {
        [Utilities showTextHUD:@"锁屏通知" andView:self.view maintainTime:5];
    }
    [[UIApplication sharedApplication]beginBackgroundTaskWithExpirationHandler:^{
        if ([_openOrcloseRecod.title isEqualToString:@"关闭视频"]) {
            [self openOrcloseVideo];
        }
    }];
    
}
-(void)enterbackGround
{
//    [[YvChatManage sharedInstance] stopCameraVideoRecord];
//    [[YvChatManage sharedInstance] chatvideo_cancelConnectToNestHost];
}
-(void)enterForGround
{
//    [[YvChatManage sharedInstance] startCameraVideoRecord];
//    [[YvChatManage sharedInstance] chatVideo_ConnectToNetHost];
}
#pragma mark - 手势识别  双击
- (IBAction)firsttap:(id)sender {
    [self changFrame:_first heigth:CGRectGetMinY(self.selfView.frame) h:_first_h w:_first_w];
    
    _first =!_first;
    
}
- (IBAction)secondTap:(id)sender {
    
    [self changFrame:_second heigth:CGRectGetMinY(self.selfView.frame) h:_second_h w:_second_w];
    
    _second = !_second;
    
}
- (IBAction)thirdTap:(id)sender {
    
    [self changFrame:_third heigth:CGRectGetHeight(self.bgview.frame)-CGRectGetMaxY(self.selfView.frame) h:_third_h w:_third_w];
    
    _third =! _third;
    
}
- (IBAction)fourtap:(id)sender {
    [self changFrame:_four heigth:CGRectGetHeight(self.bgview.frame)-CGRectGetMaxY(self.selfView.frame) h:_four_h w:_four_w];
    
    _four = !_four;
    
}
-(void)changFrame:(BOOL)tap heigth:(float)heigth h:(NSLayoutConstraint *)h w:(NSLayoutConstraint*)w
{
    if (tap)
    {
        [UIView animateWithDuration:1 animations:^{
            h.constant = heigth;
            w.constant = h.constant/128.0*100;
        } completion:^(BOOL finished) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.01 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//                [[YvChatManage sharedInstance] showVideoInView:@[self.firstImage,self.secondImage,self.thirdIMage,self.fourImage]];
                
            });
            
            
        }];
    }
    else
    {
        [UIView animateWithDuration:1 animations:^{
            h.constant =128;
            w.constant = 100;
        } completion:^(BOOL finished) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.01 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//                [[YvChatManage sharedInstance] showVideoInView:@[self.firstImage,self.secondImage,self.thirdIMage,self.fourImage]];
                
            });
            
        }];
    }

}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];

    //停止播放视频(关闭视频解码器)
//    [[YvChatManage sharedInstance] stopCameraVideoRecord];
    //停止录制视频

}
-(void)switchForCamera
{

//    [[YvChatManage sharedInstance] changeCamera];

}

-(void)openOrcloseVideo
{
    if (self.videoState)//close
    {
//        [[YvChatManage sharedInstance] stopCameraVideoRecord];
        _openOrcloseRecod.title=@"打开视频";
    }
    else //open
    {
//        [[YvChatManage sharedInstance] startCameraVideoRecord];
        _openOrcloseRecod.title=@"关闭视频";
    }
    self.videoState=!self.videoState;

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    [Utilities showTextHUD:@"内存警告" andView:self.view maintainTime:5];
    YvDebugLog(@"收到内存警告");
//    [[YvChatManage sharedInstance] stopCameraVideoRecord];
    // Dispose of any resources that can be recreated.
}


#pragma mark - YvChatManageVideoDelegate


//本地摄像头录制图片预览回调
-(void)onChatManage:(YvChatManage *)sender previewImage:(UIImage *)image
{
    self.selfView.image  = image;
}

//摄像头切换(0:不确定  1:后置摄像头  2:前置摄像头)
-(void)onChatManage:(YvChatManage *)sender didChangeCamera:(NSInteger)cameraPosition
{
    NSLog(@" cameraPosition = %d", cameraPosition);
}
//用户登陆视频结果回调 result:0 成功，其他失败, msg 失败信息 users 当前已登陆视频的用户信息(YvVideoUserInfo)   type;//0表示禁掉（不可以上传视频，被拉黑），1表示取消禁掉（取消黑名单，可以上传视频）,2表示警告中（你上传的视频内容不健康，警告你或直接拉黑你）
-(void)onChatManage:(YvChatManage *)sender videoLoginResp:(int)result msg:(NSString *)msg users:(NSArray *)users type:(int)type
{
    if (result==0) {
        YvDebugLog(@"视频连接成功");//YvChatManage登入房间成功后，在进行视频连接请求，这个回调就是视频连接请求的回调。
        
//        [[YvChatManage sharedInstance] startCameraVideoRecord];

    }
}
//其他用户登陆视频房间 的登陆状态通知 loginState 0表示离开，1表示进来
-(void)onChatManage:(YvChatManage *)sender otherUser:(UInt32)yunvaId position:(UInt8)position LoginState:(UInt8)loginState
{
    NSString *str;
    if (loginState==0) {
        str = @"离开房间";
    }else
    {
        str = @"进入房间";
    }
    YvDebugLog(@"%@",[NSString stringWithFormat:@"%@,位置:%@,%@ ",@(yunvaId),@(position),str]);
    //内存会一直增加 每次加10M
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (showHUD) {
            [Utilities showTextHUD:[NSString stringWithFormat:@"%@,位置:%@,%@ ",@(yunvaId),@(position),str] andView:self.view maintainTime:2];

        }
    });
}

//其他用户视频状态  videoState //0关闭视频，1打开视频
-(void)onChatManage:(YvChatManage *)sender otherUser:(UInt32)yunvaId nickname:(NSString *)nickname troopsId:(NSString *)troopsId VideoState:(UInt8)videoState ext:(NSString *)ext
{
    NSString *str;
    if (videoState==0) {
        str = @"关闭视频";
    }else
    {
        str = @"打开视频";
    }
    YvDebugLog(@"%@",[NSString stringWithFormat:@"%@－>%@ ",@(yunvaId),str]);
//内存会一直增加
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (showHUD) {
            [Utilities showTextHUD:[NSString stringWithFormat:@"%@－>%@ ",@(yunvaId),str] andView:self.view maintainTime:2];

        }

    });
}

@end
