//
//  YAPopoverChatVoiceTableViewCell.h
//  ChattingRoom
//
//  Created by 朱文腾 on 5/27/14.
//  Copyright (c) 2014 wind. All rights reserved.
//

#import "YAPopoverChatTableViewCell.h"
#import "YARichText.h"

@interface YAPopoverChatTextTableViewCell : YAPopoverChatTableViewCell {
    YARichText *richText;
}

@end
