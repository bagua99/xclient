//
//  ParamViewController.m
//  ChatSDKDemo_New
//
//  Created by huangzj on 15/6/1.
//  Copyright (c) 2015年 com.yunva.yaya. All rights reserved.
//

#import "ParamViewController.h"
#import "YvChatManage.h"
#import "YvAudioTools.h"

static int s_logLever = 2; //默认日志级别是 2-debug

@interface ParamViewController ()

@end

@implementation ParamViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    
    self.navigationItem.title = @"参数设置";
    self.recognizeEnable_Switch.on = self.recognizeEnable;
    self.voiceRecordMeteringEnable_Switch.on = self.audioTools.MeteringEnabled;
    self.recognizeLanguage_seg.selectedSegmentIndex = self.recognizeLanguage;
    self.outputTextLanguageType_seg.selectedSegmentIndex = self.outputTextLanguageType;
    
    self.realTimeVoice_Mute_Switch.on = [[YvChatManage sharedInstance] isPausePlayAudio];
    self.realTimeVoice_MeteringEnable_Switch.on = [YvChatManage sharedInstance].MeteringEnabled;
    self.realTimeVoice_MicMode_seg.selectedSegmentIndex = self.realTimeVoice_MicMode;
    
    self.logLevel_Seg.selectedSegmentIndex = s_logLever;
    
    
    //

    [self.voiceRecordMeteringEnable_Switch addTarget:self action:@selector(__AudioTools_MeteringEnabled_Change) forControlEvents:UIControlEventValueChanged];
    
    //
    
    [self.recognizeEnable_Switch addTarget:self action:@selector(__RecognizeEnableChange) forControlEvents:UIControlEventValueChanged];
    
    [self.recognizeLanguage_seg addTarget:self action:@selector(__RecognizeLanguageChange) forControlEvents:UIControlEventValueChanged];
    
    [self.outputTextLanguageType_seg addTarget:self action:@selector(__RecognizeOutputTextLanguageTypeChange) forControlEvents:UIControlEventValueChanged];
    
    
    //
    [self.realTimeVoice_Mute_Switch addTarget:self action:@selector(__ChatManage_Mute_Change) forControlEvents:UIControlEventValueChanged];
    [self.realTimeVoice_MeteringEnable_Switch addTarget:self action:@selector(__ChatManage_MeteringEnabled_Change) forControlEvents:UIControlEventValueChanged];
    [self.realTimeVoice_MicMode_seg addTarget:self action:@selector(__ChatManage_MicMode_Change) forControlEvents:UIControlEventValueChanged];
    [self.logLevel_Seg addTarget:self action:@selector(__ChatManage_setLogLevel) forControlEvents:UIControlEventValueChanged];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark 语音消息
-(void)__AudioTools_MeteringEnabled_Change
{
    self.audioTools.MeteringEnabled = self.voiceRecordMeteringEnable_Switch.on;
}

#pragma mark 语音识别
-(void)__RecognizeEnableChange
{
    self.recognizeEnable = self.recognizeEnable_Switch.on;
    if (self.delegate
        && [self.delegate respondsToSelector:@selector(ParamViewRecognizeEnableChange:)]) {
        
        [self.delegate ParamViewRecognizeEnableChange:self.recognizeEnable];
    }
}


-(void)__RecognizeLanguageChange
{
    self.recognizeLanguage = self.recognizeLanguage_seg.selectedSegmentIndex;
    
    if (self.delegate
        && [self.delegate respondsToSelector:@selector(ParamViewRecognizeLanguageChange:)]) {
        [self.delegate ParamViewRecognizeLanguageChange:self.recognizeLanguage];
    }
    
}

-(void)__RecognizeOutputTextLanguageTypeChange
{
    self.outputTextLanguageType = self.outputTextLanguageType_seg.selectedSegmentIndex;
    
    if (self.delegate
        && [self.delegate respondsToSelector:@selector(ParamViewOutputTextLanguageTypeChange:)]) {
        [self.delegate ParamViewOutputTextLanguageTypeChange:self.outputTextLanguageType];
    }
}


#pragma mark 实时语音
-(void)__ChatManage_Mute_Change
{
    [[YvChatManage sharedInstance] setPausePlayRealAudio:self.realTimeVoice_Mute_Switch.on];
}

-(void)__ChatManage_MicMode_Change
{
     NSInteger micMode = self.realTimeVoice_MicMode_seg.selectedSegmentIndex;
    if (self.delegate
        && [self.delegate respondsToSelector:@selector(ParamViewMicModeChange:)]) {
        
        [self.delegate ParamViewMicModeChange:micMode];
    }
}


-(void)__ChatManage_MeteringEnabled_Change
{
    [YvChatManage sharedInstance].MeteringEnabled = self.realTimeVoice_MeteringEnable_Switch.on;
}


#pragma mark 其他
-(void)__ChatManage_setLogLevel
{
    [[YvChatManage sharedInstance] setLogLevel:self.logLevel_Seg.selectedSegmentIndex];
}


@end
